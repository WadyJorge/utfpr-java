import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent {
  showMenu = false;

  toggleMenu(): void {
    this.showMenu = !this.showMenu;
  }

  onSidebarClose(): void {
    this.showMenu = false;
  }
}
