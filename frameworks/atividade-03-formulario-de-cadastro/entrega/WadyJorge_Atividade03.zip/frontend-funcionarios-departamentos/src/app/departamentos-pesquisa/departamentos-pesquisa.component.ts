import { Component } from '@angular/core';

@Component({
  selector: 'app-departamentos-pesquisa',
  templateUrl: './departamentos-pesquisa.component.html',
  styleUrls: ['./departamentos-pesquisa.component.css'],
})
export class DepartamentosPesquisaComponent {
  filtro: string = '';

  todosDepartamentos = [
    { id: 1, nomeDepartamento: 'RH' },
    { id: 2, nomeDepartamento: 'Financeiro' },
    { id: 3, nomeDepartamento: 'Marketing' },
    { id: 4, nomeDepartamento: 'TI' },
    { id: 5, nomeDepartamento: 'Comercial' },
    { id: 6, nomeDepartamento: 'Logística' },
    { id: 7, nomeDepartamento: 'Jurídico' },
    { id: 8, nomeDepartamento: 'Engenharia' },
    { id: 9, nomeDepartamento: 'Compras' },
    { id: 10, nomeDepartamento: 'Produção' },
    { id: 11, nomeDepartamento: 'Qualidade' },
  ];

  departamentos = [...this.todosDepartamentos];

  buscar() {
    this.departamentos = this.filtro
      ? this.todosDepartamentos.filter((dep) =>
          dep.nomeDepartamento.toLowerCase().includes(this.filtro.toLowerCase())
        )
      : [...this.todosDepartamentos];
  }
}
