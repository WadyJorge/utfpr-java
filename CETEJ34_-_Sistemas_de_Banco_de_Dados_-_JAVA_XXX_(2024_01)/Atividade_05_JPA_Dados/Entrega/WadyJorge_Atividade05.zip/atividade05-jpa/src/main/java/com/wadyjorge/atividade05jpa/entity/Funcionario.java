package com.wadyjorge.atividade05jpa.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name = "funcionario")
@Data
// 09. Alterar a classe Funcionario e criar uma consulta para listar os funcionários com uma determinada quantidade de dependentes por @NamedQuery
@NamedQuery(name = "Funcionario.findByDependentes", query = "SELECT f FROM Funcionario f WHERE f.dependentes = :dependentes")
// 10. Alterar a classe Funcionario e criar uma consulta para listar os funcionários que contenham em qualquer parte do seu nome um determinado nome por @NamedNativeQuery.
@NamedNativeQuery(name = "Funcionario.findByNomeContaining", query = "SELECT * FROM Funcionario f WHERE f.nome LIKE :nome", resultClass = Funcionario.class)
public class Funcionario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cod_funcionario", nullable = false)
    private Long id;

    @Column(name = "nome")
    private String nome;
    @Column(name = "dependentes")
    private int dependentes;
    @Column(name = "salario")
    private BigDecimal salario;
    @Column(name = "cargo")
    private String cargo;

    @ManyToOne
    @JoinColumn(name = "cod_departamento", nullable = false)
    private Departamento departamento;
}
