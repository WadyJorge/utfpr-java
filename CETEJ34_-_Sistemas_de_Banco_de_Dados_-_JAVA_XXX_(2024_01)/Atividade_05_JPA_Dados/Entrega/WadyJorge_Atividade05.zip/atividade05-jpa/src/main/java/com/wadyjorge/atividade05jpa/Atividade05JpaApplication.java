package com.wadyjorge.atividade05jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade05JpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(Atividade05JpaApplication.class, args);
    }

}
