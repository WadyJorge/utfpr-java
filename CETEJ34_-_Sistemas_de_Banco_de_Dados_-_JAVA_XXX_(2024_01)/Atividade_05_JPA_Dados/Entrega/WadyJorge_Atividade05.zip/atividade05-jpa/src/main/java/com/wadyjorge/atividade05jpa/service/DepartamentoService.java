package com.wadyjorge.atividade05jpa.service;

import com.wadyjorge.atividade05jpa.entity.Departamento;
import com.wadyjorge.atividade05jpa.entity.Funcionario;
import com.wadyjorge.atividade05jpa.repository.DepartamentoRepository;
import com.wadyjorge.atividade05jpa.repository.FuncionarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DepartamentoService {

    @Autowired
    private DepartamentoRepository departamentoRepository;

    @Autowired
    private FuncionarioRepository funcionarioRepository;

    // ===== atividade04-jpa =====

    // 03. Listar o primeiro departamento cadastrado.
    public Departamento findFirstByOrderByIdAsc() {
        return departamentoRepository.findFirstByOrderByIdAsc();
    }

    // ===== atividade05-jpa =====

    /* 05. Criar um método na classe de serviço de departamento para salvar um departamento, associar esse departamento a um funcionário e
    salvar esse funcionário em um mesmo controle de transação(@Transactional). */
    @Transactional
    public void salvarDepartamentoEFuncionario(Departamento departamento, Funcionario funcionario) {
        Departamento savedDepartamento = departamentoRepository.save(departamento);
        funcionario.setDepartamento(savedDepartamento);
        funcionarioRepository.save(funcionario);
    }
}
