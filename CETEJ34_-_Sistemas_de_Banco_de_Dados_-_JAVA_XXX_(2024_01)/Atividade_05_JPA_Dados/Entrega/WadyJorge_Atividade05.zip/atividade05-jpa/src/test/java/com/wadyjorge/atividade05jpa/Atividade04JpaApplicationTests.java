package com.wadyjorge.atividade05jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade05JpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
