package com.wadyjorge.atividade04jpa.service;

import com.wadyjorge.atividade04jpa.entity.Funcionario;
import com.wadyjorge.atividade04jpa.repository.FuncionarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class FuncionarioService {

    @Autowired
    private FuncionarioRepository funcionarioRepository;

    // 01. Listar um funcionário pelo seu nome e quantidade de dependentes utilizando consulta por palavras-chaves.
    public Funcionario findByNomeAndDependentes(String nome, int dependentes) {
        return funcionarioRepository.findByNomeAndDependentes(nome, dependentes);
    }

    // 02. Listar todos os funcionários de um determinado departamento por JPQL via @Query.
    public List<Funcionario> findByDepartamentoId(Long departamentoId) {
        return funcionarioRepository.findByDepartamentoId(departamentoId);
    }

    // 04. Listar o primeiro funcionário que tem o maior salário.
    public Funcionario findFirstByOrderBySalarioDesc() {
        return funcionarioRepository.findFirstByOrderBySalarioDesc();
    }

    // 05. Listar os 3 (três) primeiros funcionários que tem os maiores salários.
    public List<Funcionario> findTop3ByOrderBySalarioDesc() {
        return funcionarioRepository.findTop3ByOrderBySalarioDesc();
    }

    // 06. Listar os funcionários que não tem dependentes em ordem crescente de nome por JPQL via @Query.
    public List<Funcionario> findByDependentesIsZeroOrderByNomeAsc() {
        return funcionarioRepository.findByDependentesIsZeroOrderByNomeAsc();
    }

    // 07. Listar os funcionários que tem salário maior que um determinado valor por JPQL sobrescrevendo palavras-chaves @Query.
    public List<Funcionario> findBySalarioGreaterThan(BigDecimal salario) {
        return funcionarioRepository.findBySalarioGreaterThan(salario);
    }

    // 08. Listar os funcionários que tem salário maior que um determinado valor por @Query com native query.
    public List<Funcionario> findBySalarioGreaterThanNative(BigDecimal salario) {
        return funcionarioRepository.findBySalarioGreaterThanNative(salario);
    }

    // 09. Alterar a classe Funcionario e criar uma consulta para listar os funcionários com uma determinada quantidade de dependentes por @NamedQuery
    public List<Funcionario> findByDependentes(int dependentes) {
        return funcionarioRepository.findByDependentes(dependentes);
    }

    // 10. Alterar a classe Funcionario e criar uma consulta para listar os funcionários que contenham em qualquer parte do seu nome um determinado nome por @NamedNativeQuery.
    public List<Funcionario> findByNomeContaining(String nome) {
        return funcionarioRepository.findByNomeContaining(nome);
    }
}