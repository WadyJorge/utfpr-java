package com.wadyjorge.atividade04jpa.repository;

import com.wadyjorge.atividade04jpa.entity.Departamento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartamentoRepository extends JpaRepository<Departamento, Long> {

    // 03. Listar o primeiro departamento cadastrado.
    Departamento findFirstByOrderByIdAsc();
}
