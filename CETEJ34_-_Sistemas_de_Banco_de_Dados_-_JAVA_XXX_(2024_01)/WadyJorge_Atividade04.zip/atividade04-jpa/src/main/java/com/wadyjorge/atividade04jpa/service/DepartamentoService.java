package com.wadyjorge.atividade04jpa.service;

import com.wadyjorge.atividade04jpa.entity.Departamento;
import com.wadyjorge.atividade04jpa.repository.DepartamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DepartamentoService {

    @Autowired
    private DepartamentoRepository departamentoRepository;

    // 03. Listar o primeiro departamento cadastrado.
    public Departamento findFirstByOrderByIdAsc() {
        return departamentoRepository.findFirstByOrderByIdAsc();
    }
}
