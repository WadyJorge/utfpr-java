package com.utfpr.backendcategoriamusicasi.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name = "pessoa")
@Data
public class Pessoa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cod_Pessoa", nullable = false)
    private Long id;

    @Column(name = "nome_pessoa", length = 70)
    private String nomePessoa;

    @OneToMany(mappedBy = "pessoa")
    private List<Fone> telefones;
}
