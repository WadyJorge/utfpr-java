package com.utfpr.backendcategoriamusicasi.service;

import com.utfpr.backendcategoriamusicasi.entity.Cantor;
import com.utfpr.backendcategoriamusicasi.repository.CantorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CantorService {

    @Autowired
    private CantorRepository cantorRepository;

    public Cantor salvar(Cantor cantor) {
        return cantorRepository.save(cantor);
    }

    public void excluir(Long id) {
        cantorRepository.deleteById(id);
    }

    public Optional<Cantor> buscarPorId(Long id) {
        return cantorRepository.findById(id);
    }

    public List<Cantor> buscarPorPais(String pais) {
        return cantorRepository.findByPais(pais);
    }
}
