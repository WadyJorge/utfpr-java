package com.utfpr.backendcategoriamusicasi;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendCategoriaMusicaSiApplication {
    public static void main(String[] args) {
    }
}
