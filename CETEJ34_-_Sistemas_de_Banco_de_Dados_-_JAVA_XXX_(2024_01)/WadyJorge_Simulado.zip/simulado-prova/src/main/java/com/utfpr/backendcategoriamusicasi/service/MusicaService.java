package com.utfpr.backendcategoriamusicasi.service;

import com.utfpr.backendcategoriamusicasi.entity.Musica;
import com.utfpr.backendcategoriamusicasi.repository.MusicaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MusicaService {

    @Autowired
    private MusicaRepository musicaRepository;

    public Musica salvar(Musica musica) {
        return musicaRepository.save(musica);
    }

    public void excluir(Long id) {
        musicaRepository.deleteById(id);
    }

    public List<Musica> buscarPorTitulo(String titulo) {
        return musicaRepository.findByTituloContaining(titulo);
    }

    public Optional<Musica> buscarPorId(Long id) {
        return musicaRepository.findById(id);
    }
}
