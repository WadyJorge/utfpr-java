package com.utfpr.backendcategoriamusicasi.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "fone")
@Data
public class Fone {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cod_fone", nullable = false)
    private Long id;

    @Column(name = "numero", length = 80)
    private String numero;

    @Column(name = "tipo", nullable = false)
    private String tipo;

    @ManyToOne
    @JoinColumn(name = "cod_pessoa", nullable = false)
    private Pessoa pessoa;
}
