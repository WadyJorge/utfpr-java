package com.utfpr.backendcategoriamusicasi.repository;

import com.utfpr.backendcategoriamusicasi.entity.Fone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FoneRepository extends JpaRepository<Fone, Long> {
    List<Fone> findByTipo(String tipo);
}
