package com.utfpr.backendcategoriamusicasi.service;

import com.utfpr.backendcategoriamusicasi.entity.Gravadora;
import com.utfpr.backendcategoriamusicasi.repository.GravadoraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GravadoraService {

    @Autowired
    private GravadoraRepository gravadoraRepository;

    public Gravadora salvar(Gravadora gravadora) {
        return gravadoraRepository.save(gravadora);
    }

    public void excluir(Long id) {
        gravadoraRepository.deleteById(id);
    }

    public Optional<Gravadora> buscarPorId(Long id) {
        return gravadoraRepository.findById(id);
    }

    public List<Gravadora> buscarTodas() {
        return gravadoraRepository.findAll();
    }
}
