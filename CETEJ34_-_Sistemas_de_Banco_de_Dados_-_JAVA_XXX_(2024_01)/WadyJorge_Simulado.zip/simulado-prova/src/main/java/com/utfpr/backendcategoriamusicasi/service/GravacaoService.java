package com.utfpr.backendcategoriamusicasi.service;

import com.utfpr.backendcategoriamusicasi.entity.Gravacao;
import com.utfpr.backendcategoriamusicasi.repository.GravacaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class GravacaoService {

    @Autowired
    private GravacaoRepository gravacaoRepository;

    public Gravacao salvar(Gravacao gravacao) {
        return gravacaoRepository.save(gravacao);
    }

    public void excluir(Long id) {
        gravacaoRepository.deleteById(id);
    }

    public Optional<Gravacao> buscarPorId(Long id) {
        return gravacaoRepository.findById(id);
    }

    public List<Gravacao> buscarPorDataGravacao(LocalDate data) {
        return gravacaoRepository.findByDataGravacao(data);
    }
}
