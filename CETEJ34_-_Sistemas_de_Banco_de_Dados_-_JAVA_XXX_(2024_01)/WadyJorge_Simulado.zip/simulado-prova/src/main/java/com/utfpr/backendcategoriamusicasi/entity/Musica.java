package com.utfpr.backendcategoriamusicasi.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name = "musica")
@Data
public class Musica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cod_musica", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "cod_categoria", nullable = false)
    private Categoria categoria;

    @OneToMany(mappedBy = "musica")
    private List<Gravacao> gravacoes;

    @Column(name = "duracao", length = 11)
    private Integer duracao;

    @Column(name = "titulo", length = 100)
    private String titulo;
}
