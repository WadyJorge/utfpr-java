package com.utfpr.backendcategoriamusicasi.repository;

import com.utfpr.backendcategoriamusicasi.entity.Gravadora;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GravadoraRepository extends JpaRepository<Gravadora, Long> {
}
