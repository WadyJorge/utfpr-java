package com.utfpr.backendcategoriamusicasi.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name = "gravadora")
@Data
public class Gravadora {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cod_gravadora", nullable = false)
    private Long id;

    @Column(name = "nome_gravadora", length = 50)
    private String nomeGravadora;

    @Column(name = "pais", length = 50)
    private String pais;

    @OneToMany(mappedBy = "gravadora")
    private List<Gravacao> gravacoes;
}
