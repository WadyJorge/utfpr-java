package com.utfpr.backendcategoriamusicasi.service;

import com.utfpr.backendcategoriamusicasi.entity.Fone;
import com.utfpr.backendcategoriamusicasi.repository.FoneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FoneService {

    @Autowired
    private FoneRepository foneRepository;

    public Fone salvar(Fone fone) {
        return foneRepository.save(fone);
    }

    public void excluir(Long id) {
        foneRepository.deleteById(id);
    }

    public Optional<Fone> buscarPorId(Long id) {
        return foneRepository.findById(id);
    }

    public List<Fone> buscarPorTipo(String tipo) {
        return foneRepository.findByTipo(tipo);
    }
}
