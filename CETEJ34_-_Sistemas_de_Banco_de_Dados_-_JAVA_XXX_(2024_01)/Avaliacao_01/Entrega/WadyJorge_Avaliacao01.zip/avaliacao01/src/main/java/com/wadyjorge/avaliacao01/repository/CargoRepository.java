package com.wadyjorge.avaliacao01.repository;

import com.wadyjorge.avaliacao01.entity.Cargo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// 02. Crie as interfaces de repositório (@Repository) para as classes Funcionário e Cargo de modo a permitir o acesso aos métodos de CRUD do JpaRepository.
@Repository
public interface CargoRepository extends JpaRepository<Cargo, Integer> {
}
