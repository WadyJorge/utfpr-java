package com.wadyjorge.avaliacao01.repository;

import com.wadyjorge.avaliacao01.entity.Funcionario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

// 02. Crie as interfaces de repositório (@Repository) para as classes Funcionário e Cargo de modo a permitir o acesso aos métodos de CRUD do JpaRepository.
@Repository
public interface FuncionarioRepository extends JpaRepository<Funcionario, Integer> {
    List<Funcionario> findAllByOrderByNomeAsc(); // 07. Método para buscar funcionários em ordem alfabética pelo nome
}
