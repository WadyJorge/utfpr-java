package com.wadyjorge.avaliacao01.service;

import com.wadyjorge.avaliacao01.entity.Cargo;
import com.wadyjorge.avaliacao01.repository.CargoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/* 03 e 04. Crie as classes de serviço(@Service) para cada classe Entidade que foi implementada na questão 01, que irá formar a camada de lógica de negócios.
Cada classe deve conter:
=>Um atributo para realizar a injeção de dependências para seu Repository usando a anotação @Autowired.
=>Um método para salvar as entidades Funcionario e Cargo (incluindo o relacionamento entre elas).
=>Um método para excluir a partir do identificador - delete(ID) - um registro de cada entidade, utilizando injeção de dependências com a camada @Repository.*/

@Service
public class CargoService {

    @Autowired
    private CargoRepository cargoRepository;

    // Método para salvar um Cargo
    public Cargo salvarCargo(Cargo cargo) {
        return cargoRepository.save(cargo);
    }

    // Método para excluir um Cargo pelo ID
    public void excluirCargo(Integer id) {
        if (cargoRepository.existsById(id)) {
            cargoRepository.deleteById(id);
        } else {
            throw new RuntimeException("Cargo não encontrado para o ID: " + id);
        }
    }

    /* Crie na classe da camada de lógica de negócios (@Service), um método para cada uma das seguintes consultas, utilizando injeção de dependências com a
    camada de acesso aos dados (@Repository).
    IMPORTANTE:
        -Quando necessário, acrescentar a assinatura dos métodos na camada de acesso aos dados(@Repository).
        -O método da consulta deve ser implementado na classe (@Service) relacionada com a classe Entidade do enunciado.

    06. Método para listar todos os Cargos */
    public List<Cargo> listarTodosCargos() {
        return cargoRepository.findAll();
    }
}
