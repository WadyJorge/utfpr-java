package com.wadyjorge.avaliacao01.entity;

import jakarta.persistence.*;
import lombok.Data;

/* 01. Crie as classes com as respectivas anotações em JPA a partir do DER (Diagrama Entidade-Relacionamento) apresentado para as Entidades
(@Entity) Funcionário e Cargo; e para o Relacionamento que existe entre elas (obrigatoriamente criar o relacionamento bidirecional usando mappedBy)*/

@Entity
@Table(name = "funcionario")
@Data // Lombok para gerar automaticamente getters, setters, toString, equals, hashCode
public class Funcionario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cod_funcionario", nullable = false)
    private Integer codFuncionario;

    @Column(name = "nome", length = 70)
    private String nome;
    @Column(name = "sexo", length = 10)
    private String sexo;
    @Column(name = "telefone", length = 20)
    private String telefone;

    @ManyToOne
    @JoinColumn(name = "cod_cargo", nullable = false)
    private Cargo cargo;
}
