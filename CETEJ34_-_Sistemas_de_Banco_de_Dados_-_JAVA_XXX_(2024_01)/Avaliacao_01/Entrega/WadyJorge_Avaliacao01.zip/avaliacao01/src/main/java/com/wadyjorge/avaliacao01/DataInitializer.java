package com.wadyjorge.avaliacao01;

import com.wadyjorge.avaliacao01.entity.Cargo;
import com.wadyjorge.avaliacao01.entity.Funcionario;
import com.wadyjorge.avaliacao01.service.CargoService;
import com.wadyjorge.avaliacao01.service.FuncionarioService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/* Usando o CommandLineRunner e o Logger (e a camada de acesso aos dados e a camada de lógica de negócio criada nas questões anteriores):

09. - Inserir pelo menos 3 Cargos;
    - Inserir pelo menos 3 Funcionários (associando aos seus respectivos cargos);
    - Excluir pelo menos 1 Cargo pelo identificador (*1); e
    - Excluir pelo menos 1 Funcionário pelo identificador (*1).
      (*1) Pode ser assumido um identificador qualquer (1L) mesmo que esse não esteja cadastrado no banco. */

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

    @Autowired
    private CargoService cargoService;

    @Autowired
    private FuncionarioService funcionarioService;

    @Override
    public void run(String... args) {
        // Inserindo Cargos
        Cargo cargo1 = new Cargo();
        cargo1.setCargo("Gerente");
        cargoService.salvarCargo(cargo1);

        Cargo cargo2 = new Cargo();
        cargo2.setCargo("Desenvolvedor");
        cargoService.salvarCargo(cargo2);

        Cargo cargo3 = new Cargo();
        cargo3.setCargo("Analista");
        cargoService.salvarCargo(cargo3);

        logger.info("Cargos inseridos com sucesso.");

        // Inserindo Funcionários
        Funcionario funcionario1 = new Funcionario();
        funcionario1.setNome("Carlos Silva");
        funcionario1.setSexo("Masculino");
        funcionario1.setTelefone("123456789");
        funcionario1.setCargo(cargo1); // Associando ao cargo "Gerente"
        funcionarioService.salvarFuncionario(funcionario1);

        Funcionario funcionario2 = new Funcionario();
        funcionario2.setNome("Ana Oliveira");
        funcionario2.setSexo("Feminino");
        funcionario2.setTelefone("987654321");
        funcionario2.setCargo(cargo2); // Associando ao cargo "Desenvolvedor"
        funcionarioService.salvarFuncionario(funcionario2);

        Funcionario funcionario3 = new Funcionario();
        funcionario3.setNome("João Pereira");
        funcionario3.setSexo("Masculino");
        funcionario3.setTelefone("456789123");
        funcionario3.setCargo(cargo3); // Associando ao cargo "Analista"
        funcionarioService.salvarFuncionario(funcionario3);

        logger.info("Funcionários inseridos com sucesso.");

        // Excluindo um Cargo
        Integer cargoIdToDelete = 1; // Excluindo cargo com ID 1
        try {
            cargoService.excluirCargo(cargoIdToDelete);
            logger.info("Cargo com ID {} excluído com sucesso.", cargoIdToDelete);
        } catch (RuntimeException e) {
            logger.error("Erro ao excluir Cargo: {}", e.getMessage());
        }

        // Excluindo um Funcionário
        Integer funcionarioIdToDelete = 1; // Excluindo funcionário com ID 1
        try {
            funcionarioService.excluirFuncionario(funcionarioIdToDelete);
            logger.info("Funcionário com ID {} excluído com sucesso.", funcionarioIdToDelete);
        } catch (RuntimeException e) {
            logger.error("Erro ao excluir Funcionário: {}", e.getMessage());
        }

        /* 10. -Listar todos os Funcionários;
               -Listar todos os Cargos;
               -Listar os Funcionários em Ordem Alfabética; e
               -Listar a Quantidade de Funcionários. */

        // Listar todos os Funcionários
        logger.info("Listando todos os Funcionários:");
        funcionarioService.listarTodosFuncionarios().forEach(funcionario -> logger.info(funcionario.toString()));

        // Listar todos os Cargos
        logger.info("Listando todos os Cargos:");
        cargoService.listarTodosCargos().forEach(cargo -> logger.info(cargo.toString()));

        // Listar Funcionários em ordem alfabética
        logger.info("Listando Funcionários em Ordem Alfabética:");
        funcionarioService.listarFuncionariosEmOrdemAlfabetica().forEach(funcionario -> logger.info(funcionario.toString()));

        // Listar quantidade de Funcionários
        long quantidadeFuncionarios = funcionarioService.contarFuncionarios();
        logger.info("Quantidade de Funcionários: {}", quantidadeFuncionarios);
    }
}
