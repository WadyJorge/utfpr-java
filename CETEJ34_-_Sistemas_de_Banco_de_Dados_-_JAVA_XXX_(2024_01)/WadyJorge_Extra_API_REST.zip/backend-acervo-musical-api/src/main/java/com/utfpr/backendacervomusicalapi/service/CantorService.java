package com.utfpr.backendacervomusicalapi.service;

import com.utfpr.backendacervomusicalapi.entity.Cantor;
import com.utfpr.backendacervomusicalapi.repository.CantorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CantorService {

    @Autowired
    private CantorRepository repository;

    /*
    CRUD:
        -Create => salvar()
        -Read => listar(), encontrar()
        -Update => salvar()
        -Delete => deletar()
     */

    // Create, Update
    public Cantor salvar(Cantor cantor) {
        try {
            return repository.save(cantor);
        } catch (Exception e) {
            return null;
        }
    }

    // Read - Listar todos os cantores
    public List<Cantor> listar() {
        return repository.findAll();
    }

    // Read - Encontrar cantor por ID
    public Optional<Cantor> encontrar(Long id) {
        return repository.findById(id);
    }

    // Delete - Remover cantor por ID
    public void deletar(Long id) {
        repository.deleteById(id);
    }
}
