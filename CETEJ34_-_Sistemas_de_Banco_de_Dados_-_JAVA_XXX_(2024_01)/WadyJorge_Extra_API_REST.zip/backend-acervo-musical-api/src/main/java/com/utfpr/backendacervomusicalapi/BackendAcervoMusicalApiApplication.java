package com.utfpr.backendacervomusicalapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendAcervoMusicalApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendAcervoMusicalApiApplication.class, args);
    }

}
