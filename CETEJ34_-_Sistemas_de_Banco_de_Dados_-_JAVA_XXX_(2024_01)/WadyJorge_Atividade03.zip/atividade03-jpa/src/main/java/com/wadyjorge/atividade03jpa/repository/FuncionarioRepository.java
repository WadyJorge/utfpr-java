package com.wadyjorge.atividade03jpa.repository;

import com.wadyjorge.atividade03jpa.entity.Funcionario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FuncionarioRepository extends JpaRepository<Funcionario, Long> {
}
