package com.wadyjorge.atividade03jpa.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name = "funcionario")
@Data
public class Funcionario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cod_funcionario", nullable = false)
    private Long id;

    @Column(name = "nome")
    private String nome;
    @Column(name = "dependentes")
    private int dependentes;
    @Column(name = "salario")
    private BigDecimal salario;
    @Column(name = "cargo")
    private String cargo;

    @ManyToOne
    @JoinColumn(name = "cod_departamento", nullable = false)
    private Departamento departamento;
}
