package com.wadyjorge.atividade03jpa.service;

import com.wadyjorge.atividade03jpa.repository.DepartamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DepartamentoService {

    @Autowired
    private DepartamentoRepository repository;
}
