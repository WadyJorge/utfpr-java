package com.wadyjorge.atividade03jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade03JpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(Atividade03JpaApplication.class, args);
    }

}
