package com.wadyjorge.atividade03jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade03JpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
