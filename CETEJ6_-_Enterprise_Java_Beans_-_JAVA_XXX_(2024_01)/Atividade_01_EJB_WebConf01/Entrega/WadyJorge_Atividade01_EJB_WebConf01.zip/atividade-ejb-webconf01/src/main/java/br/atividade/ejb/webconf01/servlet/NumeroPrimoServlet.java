package br.atividade.ejb.webconf01.servlet; 

import br.atividade.ejb.webconf01.bean.NumeroPrimoBean;
import jakarta.inject.Inject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

// @author Wady Jorge
@WebServlet("/primo")
public class NumeroPrimoServlet extends HttpServlet {

    @Inject
    private NumeroPrimoBean numeroPrimoBean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Recupera o número enviado pelo formulário
        String numeroParam = request.getParameter("numero");
        int proximoPrimo = -1; // Inicializa a variável

        if (numeroParam != null && !numeroParam.isEmpty()) {
            try {
                int numero = Integer.parseInt(numeroParam);
                proximoPrimo = numeroPrimoBean.encontrarProximoPrimo(numero);
            } catch (NumberFormatException e) {
                // Trata a exceção caso a conversão falhe
                response.getWriter().println("<p>Por favor, insira um número válido.</p>");
            }
        }

        // Define o tipo de conteúdo da resposta
        response.setContentType("text/html");
        response.getWriter().println("<html>");
        response.getWriter().println("<head>");
        response.getWriter().println("<title>Próximo Número Primo</title>");
        response.getWriter().println("<style>");
        response.getWriter().println("body { display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100vh; text-align: center; margin: 0; }");
        response.getWriter().println("h1 { margin-bottom: 20px; }");
        response.getWriter().println("form { margin-bottom: 20px; }");
        response.getWriter().println("</style>");
        response.getWriter().println("</head>");
        response.getWriter().println("<body>");
        response.getWriter().println("<h1>Próximo Número Primo</h1>");
        
        // Exibe o formulário
        response.getWriter().println("<form method='GET' action='/atividade-ejb-webconf01/primo'>"); // Correção na URL de ação
        response.getWriter().println("Número: <input type='text' name='numero' required>");
        response.getWriter().println("<input type='submit' value='Calcular'>");
        response.getWriter().println("</form>");

        // Exibe o resultado se o número foi processado
        if (proximoPrimo != -1) {
            response.getWriter().println("<p>O próximo número primo após " + numeroParam + " é: " + proximoPrimo + "</p>");
        }

        response.getWriter().println("</body>");
        response.getWriter().println("</html>");
    }
}
