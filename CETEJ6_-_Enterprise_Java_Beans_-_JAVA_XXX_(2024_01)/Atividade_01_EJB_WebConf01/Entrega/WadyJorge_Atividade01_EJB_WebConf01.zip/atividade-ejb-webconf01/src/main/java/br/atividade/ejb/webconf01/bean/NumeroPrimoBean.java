package br.atividade.ejb.webconf01.bean;

import jakarta.ejb.Stateless;

// @author Wady Jorge
@Stateless
public class NumeroPrimoBean {

    // Método para calcular o próximo número primo
    public int encontrarProximoPrimo(int numero) {
        int candidato = numero + 1;
        
        while (!ehPrimo(candidato)) {
            candidato++;
        }
        
        return candidato;
    }

    // Método auxiliar para verificar se um número é primo
    private boolean ehPrimo(int numero) {
        if (numero <= 1) return false;
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) return false;
        }
        return true;
    }
}