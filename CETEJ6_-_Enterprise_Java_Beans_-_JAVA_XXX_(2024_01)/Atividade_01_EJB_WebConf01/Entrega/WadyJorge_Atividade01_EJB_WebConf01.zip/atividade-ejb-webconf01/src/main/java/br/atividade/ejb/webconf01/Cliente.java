package br.atividade.ejb.webconf01;

import br.atividade.ejb.webconf01.bean.NumeroPrimoBean;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

// @author Wady Jorge
public class Cliente {

    public static void main(String[] args) {
        try {
            Context context = new InitialContext();
            NumeroPrimoBean primoBean = (NumeroPrimoBean) context.lookup("java:global/atividade-ejb-webconf01/br.atividade.ejb.webconf01.bean.NumeroPrimoBean");

            int numero = 6;
            int proximoPrimo = primoBean.encontrarProximoPrimo(numero);
            System.out.println("O próximo número primo após o " + numero + " é: " + proximoPrimo);

        } catch (NamingException e) {
            System.err.println("Erro ao tentar localizar o bean EJB. Verifique o caminho JNDI e a configuração do servidor.");
        }
    }
}

