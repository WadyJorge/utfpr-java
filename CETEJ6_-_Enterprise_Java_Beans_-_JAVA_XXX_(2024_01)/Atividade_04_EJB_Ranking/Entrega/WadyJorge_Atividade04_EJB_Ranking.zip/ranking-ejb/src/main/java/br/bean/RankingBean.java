package br.bean;

import jakarta.ejb.Stateless;
import java.util.ArrayList;
import java.util.List;

// @author Wady Jorge
@Stateless
public class RankingBean {

    private final List<UsuarioPontuacao> ranking = new ArrayList<>();

    public void adicionarPontuacao(String nome, int pontos) {
        UsuarioPontuacao usuario = encontrarUsuario(nome);
        if (usuario == null) {
            usuario = new UsuarioPontuacao(nome, 0);
            ranking.add(usuario);
        }
        usuario.setPontuacao(usuario.getPontuacao() + pontos);
    }

    public List<UsuarioPontuacao> getRanking() {
        return ranking;
    }

    private UsuarioPontuacao encontrarUsuario(String nome) {
        for (UsuarioPontuacao usuario : ranking) {
            if (usuario.getNome().equals(nome)) {
                return usuario;
            }
        }
        return null;
    }

    public static class UsuarioPontuacao {

        private String nome;
        private int pontuacao;

        public UsuarioPontuacao(String nome, int pontuacao) {
            this.nome = nome;
            this.pontuacao = pontuacao;
        }

        public String getNome() {
            return nome;
        }

        public int getPontuacao() {
            return pontuacao;
        }

        public void setPontuacao(int pontuacao) {
            this.pontuacao = pontuacao;
        }
    }
}
