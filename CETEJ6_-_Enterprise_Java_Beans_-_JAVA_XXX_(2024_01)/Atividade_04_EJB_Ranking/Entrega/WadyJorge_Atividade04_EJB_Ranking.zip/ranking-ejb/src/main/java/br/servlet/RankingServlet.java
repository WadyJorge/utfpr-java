package br.servlet;

import br.bean.RankingBean;
import br.bean.SomaBean;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

// @author Wady Jorge
@WebServlet("/ranking")
public class RankingServlet extends HttpServlet {

    @EJB
    private SomaBean somaBean;

    @EJB
    private RankingBean rankingBean;

    private String nomeUsuario;
    private int[] numeros;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head><title>Ranking de Soma (EJB)</title></head>");
        out.println("<body>");

        // Formulário para inserir nome com URL relativa
        out.println("<h2>Informe seu nome:</h2>");
        out.println("<form method='POST' action='ranking'>");  // Use caminho relativo sem barra inicial
        out.println("<input type='text' name='nome' required>");
        out.println("<input type='submit' value='Iniciar Jogo'>");
        out.println("</form>");

        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Obtém ou cria uma nova sessão
        HttpSession session = request.getSession();

        // Recupera o nome do usuário da sessão, se já estiver definido
        String nomeUsuario = (String) session.getAttribute("nomeUsuario");
        int[] numeros = (int[]) session.getAttribute("numeros");

        String respostaSoma = request.getParameter("resposta");
        String novoNome = request.getParameter("novoNome");

        out.println("<html>");
        out.println("<head><title>Ranking de Soma (EJB)</title></head>");
        out.println("<body>");

        if (nomeUsuario == null) {
            // Se o nome do usuário não estiver na sessão, significa que é o início do jogo
            nomeUsuario = request.getParameter("nome");
            session.setAttribute("nomeUsuario", nomeUsuario);
            numeros = somaBean.gerarNumerosAleatorios();
            session.setAttribute("numeros", numeros);
        }

        if (novoNome != null && !novoNome.trim().isEmpty()) {
            // Atualiza o nome do usuário se um novo nome for fornecido
            nomeUsuario = novoNome;
            session.setAttribute("nomeUsuario", nomeUsuario);
            out.println("<p>Nome atualizado para: " + nomeUsuario + "</p>");
        }

        if (respostaSoma == null) {
            // Exibir os números e pedir a resposta
            out.println("<h2>Bem-vindo, " + nomeUsuario + "!</h2>");
            out.println("<p>Qual é a soma de: " + numeros[0] + " + " + numeros[1] + "?</p>");
            out.println("<form method='POST' action='ranking'>");
            out.println("<input type='hidden' name='nome' value='" + nomeUsuario + "'>");
            out.println("<input type='text' name='resposta' required>");
            out.println("<input type='submit' value='Verificar'>");
            out.println("</form>");

            // Formulário para trocar de nome
            out.println("<form method='POST' action='ranking'>");
            out.println("<input type='text' name='novoNome' placeholder='Novo nome' required>");
            out.println("<input type='submit' value='Trocar Nome'>");
            out.println("</form>");
        } else {
            // Validar a soma
            try {
                int somaUsuario = Integer.parseInt(respostaSoma);
                int somaCorreta = numeros[0] + numeros[1];

                if (somaBean.validarSoma(numeros[0], numeros[1], somaUsuario)) {
                    out.println("<p>Correto! Você ganhou um ponto.</p>");
                    rankingBean.adicionarPontuacao(nomeUsuario, 1);
                } else {
                    out.println("<p>Erro! A soma correta é: " + somaCorreta + ". Tente novamente.</p>");
                }
            } catch (NumberFormatException e) {
                out.println("<p>Por favor, insira um número válido.</p>");
            }

            // Gerar novos números para a próxima rodada
            numeros = somaBean.gerarNumerosAleatorios();
            session.setAttribute("numeros", numeros);

            // Exibir os números novamente
            out.println("<p>Qual é a soma de: " + numeros[0] + " + " + numeros[1] + "?</p>");
            out.println("<form method='POST' action='ranking'>");
            out.println("<input type='hidden' name='nome' value='" + nomeUsuario + "'>");
            out.println("<input type='text' name='resposta' required>");
            out.println("<input type='submit' value='Verificar'>");
            out.println("</form>");

            // Formulário para trocar de nome
            out.println("<form method='POST' action='ranking'>");
            out.println("<input type='text' name='novoNome' placeholder='Novo nome' required>");
            out.println("<input type='submit' value='Trocar Nome'>");
            out.println("</form>");
        }

        // Exibir o ranking atualizado
        out.println("<h2>====== Ranking ======</h2>");
        List<RankingBean.UsuarioPontuacao> ranking = rankingBean.getRanking();
        for (RankingBean.UsuarioPontuacao usuario : ranking) {
            out.println("<p>" + usuario.getNome() + ".... " + usuario.getPontuacao() + " pontos</p>");
        }

        out.println("</body>");
        out.println("</html>");
    }
}
