package br.ejb;

import jakarta.ejb.Stateless;

// @author WadyJorge
@Stateless
public class SomaEJB {

    public int somar(int a, int b) {
        return a + b;
    }
}
