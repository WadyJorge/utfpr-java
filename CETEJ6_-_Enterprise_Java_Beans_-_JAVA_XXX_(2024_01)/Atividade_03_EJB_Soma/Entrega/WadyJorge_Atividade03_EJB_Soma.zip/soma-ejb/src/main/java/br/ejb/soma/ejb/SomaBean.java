package br.ejb.soma.ejb;

import br.ejb.SomaEJB;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

// @author Wady Jorge
@Named
@RequestScoped
public class SomaBean {

    @EJB
    private SomaEJB somaEJB;

    private int numero1;
    private int numero2;
    private int resultado;

    public void somar() {
        resultado = somaEJB.somar(numero1, numero2);
    }

    // Getters e Setters
    public int getNumero1() {
        return numero1;
    }

    public void setNumero1(int numero1) {
        this.numero1 = numero1;
    }

    public int getNumero2() {
        return numero2;
    }

    public void setNumero2(int numero2) {
        this.numero2 = numero2;
    }

    public int getResultado() {
        return resultado;
    }

    public void setResultado(int resultado) {
        this.resultado = resultado;
    }
}
