package br.servlet;

import br.bean.CalculadoraBean;
import jakarta.inject.Inject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

// @author Wady Jorge
@WebServlet("/calculadora")
public class CalculadoraServlet extends HttpServlet {

    @Inject
    private CalculadoraBean calculadoraBean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<html>");
        response.getWriter().println("<head><title>Calcular Quadrado</title>");
        response.getWriter().println("<style>");
        response.getWriter().println("  body { display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; font-family: Arial, sans-serif; }");
        response.getWriter().println("  .container { text-align: center; }");
        response.getWriter().println("  form { margin-top: 20px; }");
        response.getWriter().println("  .button { display: inline-block; padding: 10px 20px; font-size: 16px; color: #fff; background-color: #007bff; border: none; border-radius: 4px; text-decoration: none; cursor: pointer; }");
        response.getWriter().println("  .button:hover { background-color: #0056b3; }");
        response.getWriter().println("</style>");
        response.getWriter().println("</head>");
        response.getWriter().println("<body>");
        response.getWriter().println("<div class=\"container\">");
        response.getWriter().println("<h1>Calcule o Quadrado de um Número</h1>");
        response.getWriter().println("<form action=\"calculadora\" method=\"post\">");
        response.getWriter().println("    <label for=\"numero\">Número:</label>");
        response.getWriter().println("    <input type=\"text\" id=\"numero\" name=\"numero\" required>");
        response.getWriter().println("    <button type=\"submit\">Calcular</button>");
        response.getWriter().println("</form>");
        response.getWriter().println("</div>");
        response.getWriter().println("</body>");
        response.getWriter().println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String numeroParam = request.getParameter("numero");
        int quadrado = 0;
        boolean isValidNumber = true;

        try {
            int numero = Integer.parseInt(numeroParam);
            quadrado = calculadoraBean.calcularQuadrado(numero);
        } catch (NumberFormatException e) {
            isValidNumber = false;
        }

        response.setContentType("text/html");
        response.getWriter().println("<html><head>");
        response.getWriter().println("<style>");
        response.getWriter().println("  body { display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; font-family: Arial, sans-serif; }");
        response.getWriter().println("  .container { text-align: center; }");
        response.getWriter().println("  .button { display: inline-block; padding: 10px 20px; font-size: 16px; color: #fff; background-color: #007bff; border: none; border-radius: 4px; text-decoration: none; cursor: pointer; }");
        response.getWriter().println("  .button:hover { background-color: #0056b3; }");
        response.getWriter().println("</style>");
        response.getWriter().println("</head><body>");
        response.getWriter().println("<div class=\"container\">");
        response.getWriter().println("<h1>Resultado do Cálculo</h1>");

        if (isValidNumber) {
            response.getWriter().println("<p>O quadrado de " + numeroParam + " é: " + quadrado + "</p>");
        } else {
            response.getWriter().println("<p>Erro: por favor, insira um número válido.</p>");
        }

        response.getWriter().println("<br><a href=\"calculadora\" class=\"button\">Calcular outro número</a>");
        response.getWriter().println("</div>");
        response.getWriter().println("</body></html>");
    }
}
