package br.bean;

import jakarta.ejb.Stateless;

// @author Wady Jorge
@Stateless
public class CalculadoraBean {

    public int calcularQuadrado(int numero) {
        return numero * numero;
    }
}