package br.mdb;

import br.bean.RankingBean;
import jakarta.ejb.MessageDriven;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;
import jakarta.inject.Inject;
import java.util.logging.Level;
import java.util.logging.Logger;

// @author Wady Jorge
@MessageDriven(mappedName = "jms/RankingQueue")
public class RankingMDB implements MessageListener {

    private static final Logger LOGGER = Logger.getLogger(RankingMDB.class.getName());

    @Inject
    private RankingBean rankingBean;

    @Override
    public void onMessage(Message message) {
        if (message instanceof TextMessage) {
            try {
                String texto = ((TextMessage) message).getText();
                LOGGER.info("Mensagem recebida: " + texto);

            } catch (JMSException e) {
                LOGGER.log(Level.SEVERE, "Erro ao processar a mensagem", e);
            }
        } else {
            LOGGER.log(Level.WARNING, "Mensagem recebida não é do tipo TextMessage.");
        }
    }
}
