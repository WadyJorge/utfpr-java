package br.bean;

import jakarta.ejb.Stateless;
import java.util.Random;

// @author Wady Jorge
@Stateless
public class SomaBean {

    private Random random = new Random();

    public int[] gerarNumerosAleatorios() {
        return new int[]{random.nextInt(50), random.nextInt(50)};
    }

    public boolean validarSoma(int numero1, int numero2, int somaUsuario) {
        int somaCorreta = numero1 + numero2;
        return somaCorreta == somaUsuario;
    }
}
