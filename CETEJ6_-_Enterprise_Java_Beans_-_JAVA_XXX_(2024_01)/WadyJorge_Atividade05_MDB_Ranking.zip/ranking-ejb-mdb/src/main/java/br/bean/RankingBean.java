package br.bean;

import jakarta.annotation.Resource;
import jakarta.ejb.Singleton;
import jakarta.ejb.Startup;
import jakarta.inject.Inject;
import jakarta.jms.JMSContext;
import jakarta.jms.Queue;

import java.util.*;

// @author Wady Jorge
@Startup
@Singleton
public class RankingBean {

    private final Map<String, UsuarioPontuacao> rankingMap = new HashMap<>();

    @Resource(lookup = "jms/RankingQueue")
    private Queue rankingQueue;

    @Inject
    private JMSContext jmsContext;

    // Armazena o último vencedor para evitar envios duplicados
    private String ultimoVencedor = null;

    // Adiciona ou atualiza a pontuação do usuário e envia mensagens apropriadas
    public synchronized void adicionarPontuacao(String nome, int pontos) {
        UsuarioPontuacao usuario = rankingMap.computeIfAbsent(nome, key -> new UsuarioPontuacao(key, 0));

        // Atualiza a pontuação e verifica se houve alteração
        int novaPontuacao = usuario.getPontuacao() + pontos;
        if (novaPontuacao > usuario.getPontuacao()) {
            usuario.setPontuacao(novaPontuacao);
            enviarMensagemNovoVencedor(usuario);
        }

        // Envia a lista de ranking, garantindo que esteja ordenada
        enviarListaRanking();
    }

    // Retorna a lista de ranking ordenada
    public List<UsuarioPontuacao> getRanking() {
        List<UsuarioPontuacao> rankingList = new ArrayList<>(rankingMap.values());
        rankingList.sort(Comparator.comparingInt(UsuarioPontuacao::getPontuacao).reversed());
        return rankingList;
    }

    // Envia uma mensagem informando sobre um novo vencedor
    private void enviarMensagemNovoVencedor(UsuarioPontuacao usuario) {
        // Evita envio duplicado para o mesmo vencedor
        if (!usuario.getNome().equals(ultimoVencedor)) {
            String mensagem = String.format("Novo vencedor: %s com %d pontos", usuario.getNome(), usuario.getPontuacao());
            jmsContext.createProducer().send(rankingQueue, mensagem);
            ultimoVencedor = usuario.getNome(); // Atualiza o último vencedor
        }
    }

    // Envia a lista atualizada de ranking
    private void enviarListaRanking() {
        List<UsuarioPontuacao> rankingOrdenado = getRanking();
        StringBuilder rankingMensagens = new StringBuilder("====== Ranking Atual ======\n");
        for (UsuarioPontuacao usuario : rankingOrdenado) {
            rankingMensagens.append(String.format("%s - %d pontos%n", usuario.getNome(), usuario.getPontuacao()));
        }
        jmsContext.createProducer().send(rankingQueue, rankingMensagens.toString());
    }

    // Classe interna para representar a pontuação do usuário
    public static class UsuarioPontuacao {

        private final String nome;
        private int pontuacao;

        public UsuarioPontuacao(String nome, int pontuacao) {
            this.nome = nome;
            this.pontuacao = pontuacao;
        }

        public String getNome() {
            return nome;
        }

        public int getPontuacao() {
            return pontuacao;
        }

        public void setPontuacao(int pontuacao) {
            this.pontuacao = pontuacao;
        }
    }
}
