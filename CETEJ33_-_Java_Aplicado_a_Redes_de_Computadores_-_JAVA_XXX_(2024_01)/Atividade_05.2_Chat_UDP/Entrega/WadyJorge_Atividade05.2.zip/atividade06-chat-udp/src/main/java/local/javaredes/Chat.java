package local.javaredes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.*;

public class Chat extends JFrame {
    private JTextField TfEndereco;
    private JTextField TfPorta;
    private JTextField TfUsuario;
    private JTextField TfTexto;
    private JTextArea TaTexto;
    private JButton BtConectar;
    private JButton BtEnviar;

    private MulticastSocket socket;
    private InetAddress endereco;
    private int porta;
    private String usuario;

    public Chat() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Bate-Papo (Chat)");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Painel de entrada
        JPanel panelEntrada = new JPanel();
        panelEntrada.setLayout(new FlowLayout());

        TfEndereco = new JTextField(10);
        TfPorta = new JTextField(5);
        TfUsuario = new JTextField(10);
        BtConectar = new JButton("Conectar");
        BtEnviar = new JButton("Enviar");
        TfTexto = new JTextField(20);
        TfTexto.setEnabled(false);
        BtEnviar.setEnabled(false);

        panelEntrada.add(new JLabel("Usuário:"));
        panelEntrada.add(TfUsuario);
        panelEntrada.add(new JLabel("Endereço:"));
        panelEntrada.add(TfEndereco);
        panelEntrada.add(new JLabel("Porta:"));
        panelEntrada.add(TfPorta);
        panelEntrada.add(BtConectar);

        // Área de texto
        TaTexto = new JTextArea(15, 30);
        TaTexto.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(TaTexto);

        // Painel de envio
        JPanel panelEnvio = new JPanel();
        panelEnvio.setLayout(new FlowLayout());
        panelEnvio.add(TfTexto);
        panelEnvio.add(BtEnviar);

        add(panelEntrada, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(panelEnvio, BorderLayout.SOUTH);

        BtConectar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                conectarAoServidor();
            }
        });

        BtEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                enviarMensagem();
            }
        });

        pack();
        setLocationRelativeTo(null); // Centraliza a janela
    }

    private void conectarAoServidor() {
        try {
            porta = Integer.parseInt(TfPorta.getText());
            endereco = InetAddress.getByName(TfEndereco.getText());
            usuario = TfUsuario.getText();
            socket = new MulticastSocket(porta);
            socket.joinGroup(new InetSocketAddress(endereco, porta),
                    NetworkInterface.getByInetAddress(endereco));

            TfTexto.setEnabled(true);
            BtEnviar.setEnabled(true);
            TaTexto.append("Conectado ao chat como: " + usuario + "\n");

            // Inicia a thread para receber mensagens
            new Thread(() -> receberMensagens()).start();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao conectar: " + e.getMessage());
        }
    }

    private void enviarMensagem() {
        try {
            String mensagem = TfTexto.getText();
            String mensagemCompleta = usuario + ": " + mensagem;
            byte[] msg = mensagemCompleta.getBytes();

            DatagramPacket dgPacket = new DatagramPacket(msg, msg.length, endereco, porta);
            socket.send(dgPacket);
            TaTexto.append(mensagemCompleta + "\n");
            TfTexto.setText("");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao enviar mensagem: " + e.getMessage());
        }
    }

    private void receberMensagens() {
        try {
            byte[] buffer = new byte[128];
            while (true) {
                DatagramPacket dgPacket = new DatagramPacket(buffer, buffer.length);
                socket.receive(dgPacket);

                String mensagem = new String(dgPacket.getData(), 0, dgPacket.getLength());

                // Ignora mensagens enviadas pelo próprio usuário
                if (!mensagem.startsWith(usuario + ":")) {
                    TaTexto.append(mensagem + "\n");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao receber mensagens: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Chat chat = new Chat();
            chat.setVisible(true);
        });
    }
}
