package local.javaredes;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.*;

public class Servidor extends Thread {

    private static String usuario = null;
    private static InetAddress endereco;
    private static int porta;

    @Override
    public void run() {
        try (MulticastSocket socket = new MulticastSocket(porta)) {
            socket.joinGroup(new InetSocketAddress(endereco, porta),
                    NetworkInterface.getByInetAddress(endereco));
            byte[] msg = new byte[128];

            while (!Thread.currentThread().isInterrupted()) {  // Loop seguro
                try {
                    DatagramPacket dgPacket = new DatagramPacket(msg, msg.length);
                    socket.receive(dgPacket);

                    String mensagem = new String(dgPacket.getData(), 0, dgPacket.getLength());

                    // Exibe a mensagem recebida no console do servidor
                    System.out.println("\n" + mensagem + "\n");

                    // Reenvia a mensagem para o mesmo grupo multicast
                    socket.send(new DatagramPacket(dgPacket.getData(), dgPacket.getLength(), endereco, porta));
                } catch (Exception e) {
                    System.err.println("Erro ao receber mensagens: " + e.getMessage());
                }
            }
        } catch (Exception e) {
            System.err.println("Erro ao inicializar o socket: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Parâmetros estão incorretos!\nUso: java Servidor <endereco_multicast> <porta>");
            System.exit(1);
        }

        try {
            porta = Integer.parseInt(args[1]);
            endereco = InetAddress.getByName(args[0]);

            Servidor bp = new Servidor();
            bp.start();

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

            System.out.print("Digite o seu nome: ");
            usuario = br.readLine();

            try (MulticastSocket socket = new MulticastSocket()) {
                socket.joinGroup(new InetSocketAddress(endereco, porta),
                        NetworkInterface.getByInetAddress(endereco));

                while (true) {
                    System.out.print("Digite a mensagem: ");
                    String mensagem = br.readLine();

                    if (mensagem.equalsIgnoreCase("sair")) {
                        System.out.println("Saindo do chat...");
                        socket.leaveGroup(new InetSocketAddress(endereco, porta),
                                NetworkInterface.getByInetAddress(endereco));
                        System.exit(0);
                    }

                    // Prepara a mensagem para envio
                    String mensagemCompleta = usuario + " diz: " + mensagem;
                    byte[] msg = mensagemCompleta.getBytes();

                    DatagramPacket dgPacket = new DatagramPacket(msg, msg.length, endereco, porta);
                    socket.send(dgPacket);
                }
            }
        } catch (Exception e) {
            System.err.println("Erro: " + e.getMessage());
        }
    }
}
