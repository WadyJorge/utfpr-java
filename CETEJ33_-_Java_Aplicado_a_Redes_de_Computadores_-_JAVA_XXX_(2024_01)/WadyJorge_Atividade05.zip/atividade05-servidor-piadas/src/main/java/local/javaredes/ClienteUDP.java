package local.javaredes;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class ClienteUDP {
    private static final String SERVIDOR = "localhost";
    private static final int PORTA_SERVIDOR = 9876;

    public static void main(String[] args) {
        try (DatagramSocket clienteSocket = new DatagramSocket()) {
            // Enviar uma requisição ao servidor
            byte[] bufferEnvio = "Piada, por favor!".getBytes();
            InetAddress enderecoServidor = InetAddress.getByName(SERVIDOR);
            DatagramPacket pacoteEnvio = new DatagramPacket(bufferEnvio, bufferEnvio.length, enderecoServidor, PORTA_SERVIDOR);
            clienteSocket.send(pacoteEnvio);

            // Receber a piada do servidor
            byte[] bufferRecepcao = new byte[1024];
            DatagramPacket pacoteRecepcao = new DatagramPacket(bufferRecepcao, bufferRecepcao.length);
            clienteSocket.receive(pacoteRecepcao);

            String piadaRecebida = new String(pacoteRecepcao.getData(), 0, pacoteRecepcao.getLength());
            System.out.println("Piada recebida do servidor: " + piadaRecebida);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
