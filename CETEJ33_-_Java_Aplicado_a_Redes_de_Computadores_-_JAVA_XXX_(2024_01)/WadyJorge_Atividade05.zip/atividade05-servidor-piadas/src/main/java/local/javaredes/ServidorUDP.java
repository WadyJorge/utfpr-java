package local.javaredes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

public class ServidorUDP {
    private static final int PORTA = 9876;
    private static List<String> piadas = new ArrayList<>();
    private static int indexAtual = 0;

    public static void main(String[] args) {
        carregarPiadas("src/piadas.txt");
        try (DatagramSocket servidorSocket = new DatagramSocket(PORTA)) {
            System.out.println("Servidor de piadas iniciado...");

            while (true) {
                // Recebendo o pacote do cliente
                byte[] bufferRecebido = new byte[1024];
                DatagramPacket pacoteRecebido = new DatagramPacket(bufferRecebido, bufferRecebido.length);
                servidorSocket.receive(pacoteRecebido);

                // Pegando a piada atual
                String piada = obterProximaPiada();

                // Enviando a piada ao cliente
                byte[] bufferEnviado = piada.getBytes();
                InetAddress enderecoCliente = pacoteRecebido.getAddress();
                int portaCliente = pacoteRecebido.getPort();
                DatagramPacket pacoteEnviado = new DatagramPacket(bufferEnviado, bufferEnviado.length, enderecoCliente, portaCliente);
                servidorSocket.send(pacoteEnviado);

                System.out.println("Piada enviada para " + enderecoCliente.getHostAddress() + ":" + portaCliente);
            }
        } catch (IOException e) {
            System.out.println("Erro ao iniciar o servidor ou ao enviar/receber dados: " + e.getMessage());
        }
    }

    // Carregar piadas do arquivo
    private static void carregarPiadas(String arquivo) {
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                piadas.add(linha);
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar o arquivo de piadas: " + e.getMessage());
        }
    }

    // Retornar a próxima piada
    private static String obterProximaPiada() {
        if (indexAtual < piadas.size()) {
            return piadas.get(indexAtual++);
        } else {
            return "Sem mais piadas para enviar.";
        }
    }
}
