package local.javaredes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

// @author Wady Jorge
public class Cliente extends JFrame {
    private static final String SERVER_ADDRESS = "localhost"; // Endereço do servidor
    private static final int SERVER_PORT = 50000; // Porta do servidor

    private Socket socket; // Socket para conexão com o servidor
    private PrintWriter out; // Para enviar mensagens ao servidor
    private JTextArea textArea; // Área de texto para exibir mensagens recebidas
    private JTextField textField; // Campo de texto para digitar mensagens
    private JButton sendButton; // Botão para enviar mensagens

    public Cliente() {
        // Configurações da janela
        setTitle("Cliente");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Cria e configura a área de texto
        textArea = new JTextArea();
        textArea.setEditable(false); // Área de texto é somente leitura
        JScrollPane scrollPane = new JScrollPane(textArea); // Adiciona barra de rolagem
        add(scrollPane, BorderLayout.CENTER);

        // Cria o painel para entrada de dados
        JPanel inputPanel = new JPanel();
        textField = new JTextField(30); // Campo para digitar mensagens
        sendButton = new JButton("Enviar"); // Botão para enviar mensagens

        // Adiciona componentes ao painel de entrada
        inputPanel.add(textField);
        inputPanel.add(sendButton);
        add(inputPanel, BorderLayout.SOUTH);

        // Define ações para o campo de texto e o botão
        textField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enviarMensagem(); // Envia mensagem quando Enter é pressionado
            }
        });

        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enviarMensagem(); // Envia mensagem quando o botão é clicado
            }
        });

        // Inicia a conexão com o servidor em uma nova thread
        new Thread(() -> conectarServidor()).start();
    }

    // Conecta ao servidor e inicializa o PrintWriter para envio de mensagens
    private void conectarServidor() {
        try {
            socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            out = new PrintWriter(socket.getOutputStream(), true);
            textArea.append("Conectado ao servidor " + SERVER_ADDRESS + " na porta " + SERVER_PORT + "\n");
        } catch (IOException e) {
            textArea.append("Erro ao conectar ao servidor: " + e.getMessage() + "\n");
            e.printStackTrace();
        }
    }

    // Envia a mensagem para o servidor e encerra a conexão se a mensagem for "sair"
    private void enviarMensagem() {
        String message = textField.getText();
        if (message != null && !message.trim().isEmpty()) {
            out.println(message); // Envia a mensagem para o servidor
            if ("sair".equalsIgnoreCase(message)) {
                try {
                    socket.close(); // Fecha a conexão com o servidor
                } catch (IOException e) {
                    textArea.append("Erro ao fechar a conexão: " + e.getMessage() + "\n");
                    e.printStackTrace();
                }
                textArea.append("Conexão encerrada.\n");
                System.exit(0); // Encerra o aplicativo
            }
            textField.setText(""); // Limpa o campo de texto
        }
    }

    // Método principal para iniciar a interface gráfica
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Cliente().setVisible(true));
    }
}
