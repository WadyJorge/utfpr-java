package local.javaredes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// @author Wady Jorge
public class Servidor extends JFrame {
    private static final int PORT = 50000; // Porta do servidor
    private JTextArea textArea; // Área de texto para exibir mensagens
    private ExecutorService threadPool; // Pool de threads para gerenciar múltiplos clientes
    private ServerSocket serverSocket; // Socket do servidor
    private JButton startButton; // Botão para iniciar o servidor
    private JButton stopButton; // Botão para parar o servidor
    private boolean serverRunning = false; // Flag para verificar se o servidor está rodando

    public Servidor() {
        // Configurações da janela
        setTitle("Servidor");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Cria e configura a área de texto
        textArea = new JTextArea();
        textArea.setEditable(false); // Área de texto é somente leitura
        JScrollPane scrollPane = new JScrollPane(textArea); // Adiciona barra de rolagem
        add(scrollPane, BorderLayout.CENTER);

        // Cria o painel de controle com botões
        JPanel controlPanel = new JPanel();
        startButton = new JButton("Iniciar Servidor"); // Botão para iniciar o servidor
        stopButton = new JButton("Parar Servidor"); // Botão para parar o servidor
        stopButton.setEnabled(false); // Desativa o botão de parar inicialmente

        // Adiciona botões ao painel de controle
        controlPanel.add(startButton);
        controlPanel.add(stopButton);
        add(controlPanel, BorderLayout.SOUTH);

        // Define ações para os botões
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarServidor(); // Inicia o servidor quando o botão é clicado
            }
        });

        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pararServidor(); // Para o servidor quando o botão é clicado
            }
        });

        // Cria um pool de threads com 10 threads
        threadPool = Executors.newFixedThreadPool(10);
    }

    // Inicia o servidor e aceita conexões dos clientes
    private void iniciarServidor() {
        if (serverRunning) return; // Verifica se o servidor já está rodando
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(PORT);
                textArea.append("Servidor iniciado e aguardando conexões na porta " + PORT + "\n");
                serverRunning = true; // Marca o servidor como rodando
                startButton.setEnabled(false); // Desativa o botão de iniciar
                stopButton.setEnabled(true); // Ativa o botão de parar

                // Loop para aceitar conexões dos clientes
                while (serverRunning) {
                    Socket clientSocket = serverSocket.accept();
                    textArea.append("Cliente conectado: " + clientSocket.getInetAddress() + "\n");
                    threadPool.execute(new ClienteHandler(clientSocket)); // Cria e executa uma nova thread para o cliente
                }
            } catch (IOException e) {
                textArea.append("Erro ao iniciar o servidor: " + e.getMessage() + "\n");
                e.printStackTrace();
            }
        }).start();
    }

    // Para o servidor e fecha o socket
    private void pararServidor() {
        if (!serverRunning) return; // Verifica se o servidor está rodando
        try {
            serverRunning = false; // Marca o servidor como não rodando
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close(); // Fecha o socket do servidor
            }
            textArea.append("Servidor parado.\n");
            startButton.setEnabled(true); // Ativa o botão de iniciar
            stopButton.setEnabled(false); // Desativa o botão de parar
        } catch (IOException e) {
            textArea.append("Erro ao parar o servidor: " + e.getMessage() + "\n");
            e.printStackTrace();
        }
    }

    // Classe para gerenciar a comunicação com cada cliente
    class ClienteHandler implements Runnable {
        private Socket clienteSocket; // Socket do cliente

        public ClienteHandler(Socket clienteSocket) {
            this.clienteSocket = clienteSocket;
        }

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clienteSocket.getInputStream()))) {
                String message;
                while ((message = in.readLine()) != null) {
                    if ("sair".equalsIgnoreCase(message)) {
                        textArea.append("Cliente " + clienteSocket.getInetAddress() + " desconectado.\n");
                        break;
                    }
                    textArea.append("Mensagem recebida de " + clienteSocket.getInetAddress() + ": " + message + "\n");
                }
            } catch (IOException e) {
                textArea.append("Erro ao processar a mensagem: " + e.getMessage() + "\n");
                e.printStackTrace();
            } finally {
                try {
                    clienteSocket.close(); // Fecha o socket do cliente
                } catch (IOException e) {
                    textArea.append("Erro ao fechar o socket do cliente: " + e.getMessage() + "\n");
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Servidor().setVisible(true)); // Inicia a interface gráfica
    }
}
