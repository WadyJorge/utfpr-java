package local.javaredes;

import javax.swing.*;
import java.awt.*;
import java.io.PrintWriter;
import java.net.Socket;

public class Cliente extends JFrame {
    private JTextField campoNome;
    private JTextArea areaMensagens;
    private PrintWriter escritor;
    private Socket socket;

    public Cliente() {
        setTitle("Cliente");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        campoNome = new JTextField(20);
        areaMensagens = new JTextArea(10, 30);
        areaMensagens.setEditable(false);

        JButton botaoEnviar = new JButton("Enviar");
        botaoEnviar.addActionListener(e -> enviarMensagem());

        JPanel painel = new JPanel();
        painel.add(new JLabel("Nome:"));
        painel.add(campoNome);
        painel.add(botaoEnviar);

        add(painel, BorderLayout.NORTH);
        add(new JScrollPane(areaMensagens), BorderLayout.CENTER);

        setVisible(true);
        conectarAoServidor();
    }

    private void conectarAoServidor() {
        try {
            socket = new Socket("localhost", 12345);
            escritor = new PrintWriter(socket.getOutputStream(), true);
            String nome = campoNome.getText();
            escritor.println(nome);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void enviarMensagem() {
        String mensagem = JOptionPane.showInputDialog(this, "Digite sua mensagem:");
        if (mensagem != null && !mensagem.trim().isEmpty()) {
            escritor.println(mensagem);
            areaMensagens.append("Você: " + mensagem + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Cliente::new);
    }
}
