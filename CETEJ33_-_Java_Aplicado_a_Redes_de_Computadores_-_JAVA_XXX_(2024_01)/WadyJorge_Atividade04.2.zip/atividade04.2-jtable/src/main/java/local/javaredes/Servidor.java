package local.javaredes;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Servidor extends JFrame {
    private JTable tabela;
    private DefaultTableModel modeloTabela;
    private List<ClientHandler> clientes;
    private int contadorClientes;
    private JTextField campoPorta;
    private JButton botaoIniciar;
    private JTabbedPane aba;
    private JTextArea areaMensagens;

    public Servidor() {
        setTitle("Servidor");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        clientes = new ArrayList<>();
        modeloTabela = new DefaultTableModel(new String[]{"Cliente", "Status"}, 0);

        tabela = new JTable(modeloTabela);

        aba = new JTabbedPane();

        JPanel painelConexoes = new JPanel(new BorderLayout());
        painelConexoes.add(new JScrollPane(tabela), BorderLayout.CENTER);

        aba.addTab("Conexões", painelConexoes);

        JPanel painelDados = new JPanel(new BorderLayout());

        areaMensagens = new JTextArea();
        areaMensagens.setEditable(false);
        painelDados.add(new JLabel("Mensagens dos Clientes:"), BorderLayout.NORTH);
        painelDados.add(new JScrollPane(areaMensagens), BorderLayout.CENTER);

        aba.addTab("Dados", painelDados);

        JPanel painelEntrada = new JPanel();
        painelEntrada.setLayout(new FlowLayout());

        campoPorta = new JTextField(10);
        campoPorta.setText("12345");
        botaoIniciar = new JButton("Iniciar Servidor");
        botaoIniciar.addActionListener(e -> iniciarServidor());

        painelEntrada.add(new JLabel("Porta:"));
        painelEntrada.add(campoPorta);
        painelEntrada.add(botaoIniciar);

        add(painelEntrada, BorderLayout.NORTH);
        add(aba, BorderLayout.CENTER);

        setVisible(true);
        contadorClientes = 1;
    }

    private void iniciarServidor() {
        int porta;
        try {
            porta = Integer.parseInt(campoPorta.getText());
            new Thread(() -> {
                try (ServerSocket serverSocket = new ServerSocket(porta)) {
                    System.out.println("Servidor iniciado na porta " + porta + ". Aguardando conexões...");

                    while (true) {
                        try {
                            Socket socket = serverSocket.accept();
                            ClientHandler clienteHandler = new ClientHandler(socket, this, contadorClientes);
                            clientes.add(clienteHandler);
                            contadorClientes++;
                            new Thread(clienteHandler).start();
                        } catch (IOException e) {
                            System.err.println("Erro ao aceitar conexão: " + e.getMessage());
                        }
                    }
                } catch (IOException e) {
                    System.err.println("Erro ao iniciar o servidor: " + e.getMessage());
                }
            }).start();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, insira um número de porta válido.",
                    "Erro de Porta", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void atualizarTabela(int clienteId, String status) {
        SwingUtilities.invokeLater(() -> {
            String nomeCliente = "Cliente " + clienteId;
            for (int i = 0; i < modeloTabela.getRowCount(); i++) {
                if (modeloTabela.getValueAt(i, 0).equals(nomeCliente)) {
                    modeloTabela.setValueAt(status, i, 1);
                    return;
                }
            }
            modeloTabela.addRow(new Object[]{nomeCliente, status});
        });
    }

    // Método para atualizar a área de mensagens
    public void adicionarMensagem(String mensagem) {
        if (mensagem != null && !mensagem.trim().isEmpty()) {
            SwingUtilities.invokeLater(() -> {
                areaMensagens.append(mensagem + "\n");
                areaMensagens.setCaretPosition(areaMensagens.getDocument().getLength());
            });
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Servidor::new);
    }
}

class ClientHandler implements Runnable {
    private Socket socket;
    private Servidor servidor;
    private int clienteId;

    public ClientHandler(Socket socket, Servidor servidor, int clienteId) {
        this.socket = socket;
        this.servidor = servidor;
        this.clienteId = clienteId;
    }

    @Override
    public void run() {
        try (BufferedReader leitor = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            servidor.atualizarTabela(clienteId, "Conectado");

            String mensagem;
            while ((mensagem = leitor.readLine()) != null) {
                if (mensagem.trim().isEmpty()) {
                    continue;
                }
                System.out.println("Cliente " + clienteId + ": " + mensagem);
                servidor.adicionarMensagem("Cliente " + clienteId + ": " + mensagem);
            }
        } catch (IOException e) {
            System.err.println("Erro de I/O com o Cliente " + clienteId + ": " + e.getMessage());
        } finally {
            servidor.atualizarTabela(clienteId, "Desconectado");
            try {
                socket.close();
            } catch (IOException e) {
                System.err.println("Erro ao fechar o socket do Cliente " + clienteId + ": " + e.getMessage());
            }
        }
    }
}
