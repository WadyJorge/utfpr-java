package local.javaredes;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;

// @author Wady Jorge
public class Servidor {

    public static void main(String[] args) {
        // Inicializa a interface gráfica
        SwingUtilities.invokeLater(() -> {
            // Criação da janela principal (JFrame) para o servidor
            JFrame frame = new JFrame("Servidor de Verificação de CPF");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 200);
            frame.setLayout(new BorderLayout());

            // Área de texto para exibir logs do servidor
            JTextArea logArea = new JTextArea();
            logArea.setEditable(false);
            frame.add(new JScrollPane(logArea), BorderLayout.CENTER);

            // Inicializa o servidor na porta 50000
            try (ServerSocket servidor = new ServerSocket(50000)) {
                logArea.append("Servidor iniciado e aguardando conexões...\n");

                while (true) {
                    try {
                        // Aceita a conexão do cliente
                        Socket conexao = servidor.accept();
                        logArea.append("Cliente conectado.\n");

                        // Cria streams para comunicação com o cliente
                        ObjectInputStream entrada = new ObjectInputStream(conexao.getInputStream());
                        String cpf = (String) entrada.readObject();

                        // Verifica o CPF e gera o resultado
                        String resultado = verificarCpf(cpf);

                        ObjectOutputStream saida = new ObjectOutputStream(conexao.getOutputStream());
                        saida.writeObject(resultado);
                        saida.flush();

                        // Fecha os streams e a conexão com o cliente
                        entrada.close();
                        saida.close();
                        conexao.close();

                        logArea.append("Conexão encerrada.\n");
                    } catch (IOException | ClassNotFoundException e) {
                        logArea.append("Ocorreu um erro durante a comunicação com o cliente. " +
                                       "Verifique se o cliente está conectado e se os dados estão corretos.\n");
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                logArea.append("Ocorreu um erro ao iniciar o servidor.\n");
                e.printStackTrace();
            }

            // Centraliza a janela na tela
            frame.setLocationRelativeTo(null);

            // Exibe a janela do servidor
            frame.setVisible(true);
        });
    }

    // Método para verificar a validade do CPF
    private static String verificarCpf(String cpf) {
        // Remove pontos e hífens, se presentes
        cpf = cpf.replaceAll("[^0-9]", "");

        // Verifica se o CPF tem 11 dígitos e não é uma sequência de zeros
        if (cpf.length() != 11 || cpf.matches("0{11}")) {
            return "Este CPF é inválido.";
        }

        // Calcula o primeiro dígito verificador
        int soma = 0;
        for (int i = 0; i < 9; i++) {
            soma += (10 - i) * Character.getNumericValue(cpf.charAt(i));
        }
        int digito1 = (soma % 11 < 2) ? 0 : 11 - (soma % 11);

        // Calcula o segundo dígito verificador
        soma = 0;
        for (int i = 0; i < 10; i++) {
            soma += (11 - i) * Character.getNumericValue(cpf.charAt(i));
        }
        int digito2 = (soma % 11 < 2) ? 0 : 11 - (soma % 11);

        // Verifica se os dígitos verificadores são válidos
        if (digito1 == Character.getNumericValue(cpf.charAt(9)) &&
                digito2 == Character.getNumericValue(cpf.charAt(10))) {
            return "Este CPF é válido.";
        } else {
            return "Este CPF é inválido.";
        }
    }
}
