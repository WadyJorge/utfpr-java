package local.javaredes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;

// @author Wady Jorge
public class Cliente {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Criação da janela principal (JFrame)
            JFrame frame = new JFrame("Validador de CPF");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 200);
            frame.setLayout(new BorderLayout());

            // Painel principal com GridBagLayout para melhor controle de tamanho
            JPanel panel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5); // Define espaçamento entre os componentes
            gbc.fill = GridBagConstraints.HORIZONTAL;

            // Campo de texto para o CPF
            JTextField cpfField = new JTextField(15);
            JButton enviarButton = new JButton("Verificar");
            JButton limparButton = new JButton("Limpar");
            JTextArea respostaArea = new JTextArea();
            respostaArea.setEditable(false);

            // Rótulo para status do servidor
            JLabel statusLabel = new JLabel("Status do servidor: Desconhecido");
            statusLabel.setForeground(Color.RED);

            // Configurando o rótulo de instrução
            gbc.gridx = 0; // Posição da coluna
            gbc.gridy = 0; // Posição da linha
            gbc.gridwidth = 2; // Mescla duas colunas para o label
            panel.add(new JLabel("Digite um CPF para verificação:"), gbc);

            // Configurando o campo de texto para CPF
            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 1; // Ocupa uma coluna
            panel.add(cpfField, gbc);

            // Configurando o botão "Verificar"
            gbc.gridx = 1;
            gbc.gridy = 1;
            panel.add(enviarButton, gbc);

            // Configurando o botão "Limpar"
            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 2; // Ocupa duas colunas
            panel.add(limparButton, gbc);

            // Adicionando o rótulo de status do servidor
            gbc.gridx = 0;
            gbc.gridy = 3;
            gbc.gridwidth = 2;
            panel.add(statusLabel, gbc);

            // Adicionando o painel à parte superior da janela
            frame.add(panel, BorderLayout.NORTH);

            // Adicionando a área de resposta à parte central da janela
            frame.add(new JScrollPane(respostaArea), BorderLayout.CENTER);

            // Verifica o status do servidor na inicialização
            verificarStatusServidor(statusLabel);

            // Ação do botão "Enviar"
            enviarButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String cpf = cpfField.getText();
                    if (statusLabel.getText().contains("Online")) {
                        try {
                            Socket conexao = new Socket("127.0.0.1", 50000);
                            ObjectOutputStream saida = new ObjectOutputStream(conexao.getOutputStream());
                            saida.writeObject(cpf);
                            saida.flush();

                            ObjectInputStream entrada = new ObjectInputStream(conexao.getInputStream());
                            String resposta = (String) entrada.readObject();
                            respostaArea.setText(resposta);

                            entrada.close();
                            saida.close();
                            conexao.close();
                        } catch (IOException | ClassNotFoundException ex) {
                            statusLabel.setText("Status do servidor: Offline");
                            statusLabel.setForeground(Color.RED);
                            JOptionPane.showMessageDialog(frame, "Ocorreu um erro na comunicação com o servidor. " +
                                           "Verifique a conexão e tente novamente.", "Erro", JOptionPane.ERROR_MESSAGE);
                            ex.printStackTrace();
                        }
                    } else {
                        respostaArea.setText("O servidor está offline. Não foi possível verificar o CPF.");
                    }
                }
            });

            // Ação do botão "Limpar"
            limparButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cpfField.setText(""); // Limpa o campo de texto do CPF
                    respostaArea.setText(""); // Limpa a área de resposta
                }
            });

            // Centraliza a janela na tela
            frame.setLocationRelativeTo(null);

            // Exibe a janela do Cliente
            frame.setVisible(true);
        });
    }

    // Método para verificar o status do servidor
    private static void verificarStatusServidor(JLabel statusLabel) {
        try {
            Socket conexao = new Socket("127.0.0.1", 50000);
            conexao.close();
            statusLabel.setText("Status do servidor: Online");
            statusLabel.setForeground(Color.GREEN);
        } catch (IOException e) {
            statusLabel.setText("Status do servidor: Offline");
            statusLabel.setForeground(Color.RED);
        }
    }
}
