package local.javaredes;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

// @author Wady Jorge
public class Servidor {
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(50000)) {
            System.out.println("Servidor iniciado. Aguardando conexões...");
            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(new ClienteHandler(socket)).start();
            }
        } catch (IOException e) {
            System.err.println("Erro ao iniciar o servidor: " + e.getMessage());
        }
    }
}

class ClienteHandler implements Runnable {
    private Socket socket;

    public ClienteHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
             PrintWriter output = new PrintWriter(socket.getOutputStream(), true)) {

            // Recebe o objeto Pessoa do cliente
            Pessoa pessoa = (Pessoa) input.readObject();

            // Exibe os dados recebidos no console do servidor
            System.out.println("Dados recebidos do cliente:");
            System.out.println("Nome: " + pessoa.getNome());
            System.out.println("Idade: " + pessoa.getIdade());

            // Envia mensagem de confirmação para o cliente
            output.println("Dados recebidos com sucesso!");

        } catch (IOException e) {
            System.err.println("Erro de I/O: Verifique o tipo de dado inserido!");
        } catch (ClassNotFoundException e) {
            System.err.println("Classe não encontrada: " + e.getMessage());
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                System.err.println("Erro ao fechar o socket: " + e.getMessage());
            }
        }
    }
}
