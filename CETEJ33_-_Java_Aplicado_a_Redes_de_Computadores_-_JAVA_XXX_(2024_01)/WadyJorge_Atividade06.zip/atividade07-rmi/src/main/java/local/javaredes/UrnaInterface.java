package local.javaredes;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;

// @author Wady Jorge
public interface UrnaInterface extends Remote {
    void adicionarVotos(String nomeCandidato, int votos) throws RemoteException;

    Map<String, Integer> obterResultadoAtualizado() throws RemoteException;
}
