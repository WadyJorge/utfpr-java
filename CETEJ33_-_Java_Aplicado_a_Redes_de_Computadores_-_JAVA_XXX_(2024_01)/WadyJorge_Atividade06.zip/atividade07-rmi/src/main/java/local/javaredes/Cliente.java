package local.javaredes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.Naming;

// @author Wady Jorge
public class Cliente extends JFrame {
    private UrnaInterface urna;
    private JComboBox<String> candidatoComboBox;
    private JTextField votosField;

    public Cliente() {
        try {
            urna = (UrnaInterface) Naming.lookup("rmi://localhost:1099/UrnaEletronica");

            setTitle("Urna Eletrônica - RMI");
            setSize(500, 190);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);

            configureComponents();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao conectar-se à Urna Eletrônica:\n" +
                            "O Servidor não foi iniciado!", "Erro de Conexão", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    private void configureComponents() {
        String[] candidatos = {"10 - Wady Jorge", "22 - Maria Silva", "35 - Vitor Costa", "48 - Paulo Sousa", "52 - Ana Lima"};
        candidatoComboBox = new JComboBox<>(candidatos);
        votosField = new JTextField(10);

        JButton enviarVotosButton = new JButton("Enviar ao Servidor");
        JButton cadastrarCandidatoButton = new JButton("Cadastrar Candidato");
        JButton encerrarUrnaButton = new JButton("Encerrar Urna");

        enviarVotosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enviarVotos();
            }
        });

        cadastrarCandidatoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarCandidato();
            }
        });

        encerrarUrnaButton.addActionListener(e -> encerrarUrna());

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.add(createInputPanel(cadastrarCandidatoButton), BorderLayout.NORTH);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        actionPanel.add(enviarVotosButton);
        actionPanel.add(encerrarUrnaButton);

        enviarVotosButton.setPreferredSize(new Dimension(150, 30));
        encerrarUrnaButton.setPreferredSize(new Dimension(150, 30));

        mainPanel.add(actionPanel, BorderLayout.CENTER);

        add(mainPanel);
    }

    private JPanel createInputPanel(JButton cadastrarCandidatoButton) {
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Candidato:"), gbc);

        gbc.gridx = 1;
        inputPanel.add(candidatoComboBox, gbc);

        gbc.gridx = 2;
        inputPanel.add(cadastrarCandidatoButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Quantidade de Votos:"), gbc);

        gbc.gridx = 1;
        inputPanel.add(votosField, gbc);

        inputPanel.setBorder(BorderFactory.createTitledBorder(""));
        return inputPanel;
    }

    private void enviarVotos() {
        try {
            String nomeCandidato = (String) candidatoComboBox.getSelectedItem();
            int votos = Integer.parseInt(votosField.getText());
            urna.adicionarVotos(nomeCandidato, votos);
            JOptionPane.showMessageDialog(this, "Dados enviados com sucesso!");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor, insira um número válido de votos.",
                    "Erro de Entrada", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao enviar dados.",
                    "Erro de Conexão", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cadastrarCandidato() {
        String novoCandidato = JOptionPane.showInputDialog(this, "Digite o nome do novo candidato:");
        if (novoCandidato != null && !novoCandidato.trim().isEmpty()) {
            candidatoComboBox.addItem(novoCandidato.trim());
            JOptionPane.showMessageDialog(this, "Candidato cadastrado com sucesso!");
        }
    }

    private void encerrarUrna() {
        JOptionPane.showMessageDialog(this, "Encerrando a urna...");
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Cliente cliente = new Cliente();
            cliente.setVisible(true);
        });
    }
}
