package local.javaredes;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;

// @author Wady Jorge
public class Servidor extends UnicastRemoteObject implements UrnaInterface {
    private Map<String, Integer> votos;

    public Servidor() throws RemoteException {
        super();
        votos = new HashMap<>();
    }

    @Override
    public void adicionarVotos(String nomeCandidato, int votosRecebidos) throws RemoteException {
        votos.put(nomeCandidato, votos.getOrDefault(nomeCandidato, 0) + votosRecebidos);
        System.out.println("Votos atualizados para o candidato " + nomeCandidato + ": " + votos.get(nomeCandidato));
    }

    @Override
    public Map<String, Integer> obterResultadoAtualizado() throws RemoteException {
        return votos;
    }

    public static void main(String[] args) {
        try {
            LocateRegistry.createRegistry(1099);
            System.out.println("Registro RMI iniciado na porta 1099.");

            Servidor servidor = new Servidor();
            Naming.rebind("rmi://localhost:1099/UrnaEletronica", servidor);
            System.out.println("Servidor RMI pronto e aguardando conexões.");

            while (true) {
                Thread.sleep(5000);
                System.out.println("Resultados da apuração: " + servidor.obterResultadoAtualizado());
            }
        } catch (Exception e) {
            System.err.println("Erro ao iniciar o servidor: " + e.getMessage());
        }
    }
}
