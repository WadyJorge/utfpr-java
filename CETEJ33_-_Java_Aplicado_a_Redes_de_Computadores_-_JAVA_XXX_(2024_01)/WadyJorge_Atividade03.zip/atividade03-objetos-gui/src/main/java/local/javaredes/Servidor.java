package local.javaredes;

import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

// @author Wady Jorge
public class Servidor {

    public static void main(String[] args) {
        ServerSocket servidor = null;
        Socket socket = null;
        ObjectInputStream entrada = null;

        try {
            // Cria o servidor na porta 50000
            servidor = new ServerSocket(50000);
            System.out.println("Servidor iniciado. Aguardando conexões...");

            // Aceita a conexão do cliente
            socket = servidor.accept();
            System.out.println("Cliente conectado.");

            // Recebe o objeto Pessoa do cliente
            entrada = new ObjectInputStream(socket.getInputStream());
            Pessoa pessoa = (Pessoa) entrada.readObject();

            // Exibe os dados recebidos no console do servidor
            System.out.println("Dados recebidos do cliente:");
            System.out.println("Nome: " + pessoa.getNome());
            System.out.println("Idade: " + pessoa.getIdade());

        } catch (Exception e) {
            System.err.println("Erro no servidor: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (entrada != null) entrada.close();
            } catch (Exception e) {
                System.err.println("Erro ao fechar o stream de entrada: " + e.getMessage());
            }

            try {
                if (socket != null) socket.close();
            } catch (Exception e) {
                System.err.println("Erro ao fechar o socket: " + e.getMessage());
            }

            try {
                if (servidor != null) servidor.close();
            } catch (Exception e) {
                System.err.println("Erro ao fechar o servidor: " + e.getMessage());
            }

            System.out.println("Servidor encerrado.");
        }
    }
}
