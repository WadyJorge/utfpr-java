package local.javaredes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectOutputStream;
import java.net.Socket;

// @author Wady Jorge
public class FormCliente extends JFrame {
    private JTextField txtNome;
    private JTextField txtIdade;
    private JTextArea txtStatus;

    public FormCliente() {
        // Configurações da interface gráfica
        setTitle("Cliente");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Centraliza a janela

        // Campos de texto para nome e idade
        txtNome = new JTextField(20);
        txtIdade = new JTextField(20);
        txtStatus = new JTextArea(5, 30);
        txtStatus.setEditable(false);

        // Botão de envio
        JButton btnEnviar = new JButton("Enviar");
        btnEnviar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                enviarDados();
            }
        });

        // Layout e posicionamento
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Configurações de espaçamento
        gbc.insets = new Insets(5, 5, 5, 5);

        // Adiciona os componentes ao painel usando GridBagLayout
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Nome:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(txtNome, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Idade:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(txtIdade, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(new JLabel("Retorno do Servidor:"), gbc);

        // Adiciona a caixa de texto de status
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panel.add(new JScrollPane(txtStatus), gbc);

        // Painel para o botão "Enviar", alinhado à direita
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(btnEnviar);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.EAST; // Alinha o painel do botão à direita
        panel.add(buttonPanel, gbc);

        add(panel);
    }

    // Método para enviar os dados
    private void enviarDados() {
        Socket socket = null;
        ObjectOutputStream saida = null;

        try {
            // Cria a conexão com o servidor
            socket = new Socket("127.0.0.1", 50000);

            // Cria o objeto Pessoa com os dados do formulário
            Pessoa pessoa = new Pessoa();
            pessoa.setNome(txtNome.getText());
            pessoa.setIdade(Integer.parseInt(txtIdade.getText()));

            // Envia o objeto Pessoa para o servidor
            saida = new ObjectOutputStream(socket.getOutputStream());
            saida.writeObject(pessoa);
            txtStatus.append("Dados recebidos corretamente.\n");

        } catch (Exception e) {
            txtStatus.append("Erro ao enviar dados: " + e.getMessage() + "\n");
            e.printStackTrace();
        } finally {
            try {
                if (saida != null) saida.close();
            } catch (Exception e) {
                txtStatus.append("Erro ao fechar o stream de saída: " + e.getMessage() + "\n");
            }

            try {
                if (socket != null) socket.close();
            } catch (Exception e) {
                txtStatus.append("Erro ao fechar o socket: " + e.getMessage() + "\n");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FormCliente cliente = new FormCliente();
            cliente.setVisible(true);
        });
    }
}
