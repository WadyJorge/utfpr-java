public interface Calcular {

    public int calcular();

}