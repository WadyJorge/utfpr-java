// @author Wady Jorge Souza Beliche
public interface Verifica {
    
    public void validar();
}
