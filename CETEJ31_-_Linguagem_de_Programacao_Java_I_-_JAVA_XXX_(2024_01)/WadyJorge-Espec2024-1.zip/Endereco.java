// @author Wady Jorge Souza Beliche
public class Endereco {
    
    private int num = 0;
    private String rua = " ";
    
    // Getters e Setters
    public int getNum() {
        return num;
    }
    
    public void setNum(int num) {
        this.num = num;
    }
    
    public String getRua() {
        return rua;
    }
    
    public void setRua(String rua) {
        this.rua = rua;
    }
}
