public class VelocException extends Exception {

    public VelocException(){
        super("======================== ATENÇÃO! ======================== \n A velocidade máxima está fora dos limites brasileiros!");
    }

}