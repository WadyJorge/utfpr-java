public class VelocException extends Exception {

    public String mensagemErro() {
		return "ATENÇÃO: A velocidade máxima está fora dos limites brasileiros!";
	}
    
}