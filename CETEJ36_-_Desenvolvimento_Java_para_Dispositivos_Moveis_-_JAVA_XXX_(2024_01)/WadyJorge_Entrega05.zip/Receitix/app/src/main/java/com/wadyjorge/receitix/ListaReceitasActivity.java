package com.wadyjorge.receitix;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.view.ActionMode;

import java.util.ArrayList;

public class ListaReceitasActivity extends AppCompatActivity {

    // Constante para preferências
    public static final String ARQUIVO_PREFERENCIAS = "com.wadyjorge.receitix.PREFERENCIAS";
    public static final String KEY_ORDENACAO_CRESCENTE = "ORDENACAO_CRESCENTE";
    public static final String KEY_MODO_NOTURNO = "MODO_NOTURNO";
    public static final Boolean PADRAO_INICIAL_ORDENACAO_CRESCENTE = true;
    public static final Boolean PADRAO_INICIAL_MODO_NOTURNO = false;

    // Componentes da interface
    private ListView listViewReceitas;
    private ArrayList<Receita> listaReceitas;
    private ReceitaAdapter receitaAdapter;
    private MenuItem menuItemOrdenar;
    private MenuItem menuItemModoNoturno;

    // Variáveis de estado
    private boolean ordenacaoCrescente = PADRAO_INICIAL_ORDENACAO_CRESCENTE;
    private boolean modoNoturno = PADRAO_INICIAL_MODO_NOTURNO;
    private int posicaoSelecionada = -1;
    private ActionMode actionMode;
    private View itemSelecionado;
    private Drawable backgroundItem;

    // Ciclo de vida da Activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_receitas);
        setTitle(R.string.lista_de_receitas);

        inicializarComponentes();
        lerPreferencias();
        aplicarTema();
        configurarListeners();
    }

    // Inicializa os componentes da interface e configura o adaptador da lista
    private void inicializarComponentes() {
        listViewReceitas = findViewById(R.id.listViewReceitas);
        listaReceitas = new ArrayList<>();
        receitaAdapter = new ReceitaAdapter(this, listaReceitas);
        listViewReceitas.setAdapter(receitaAdapter);
    }

    // Lê as preferências armazenadas
    private void lerPreferencias() {
        SharedPreferences shared = getSharedPreferences(ListaReceitasActivity.ARQUIVO_PREFERENCIAS, Context.MODE_PRIVATE);
        ordenacaoCrescente = shared.getBoolean(KEY_ORDENACAO_CRESCENTE, ordenacaoCrescente);
        modoNoturno = shared.getBoolean(KEY_MODO_NOTURNO, modoNoturno);
    }

    // Aplica o tema com base nas preferências
    private void aplicarTema() {

        if (modoNoturno) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    // Define os eventos de clique e clique longo para a lista
    private void configurarListeners() {
        listViewReceitas.setOnItemClickListener((parent, view, position, id) -> {
            posicaoSelecionada = position;
            editarReceita();
        });

        listViewReceitas.setOnItemLongClickListener((parent, view, position, id) -> {

            if (actionMode != null) {
                return false;
            }

            selecionarItem(view, position);
            actionMode = startSupportActionMode(actionCallback);
            return true;
        });
    }

    // Destaca visualmente um item selecionado e desativa interações na lista
    private void selecionarItem(View view, int position) {
        posicaoSelecionada = position;
        itemSelecionado = view;
        backgroundItem = view.getBackground();
        view.setBackgroundColor(Color.LTGRAY);
        listViewReceitas.setEnabled(false);
    }

    // Cria o menu de opções da ActionBar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.lista_receitas_opcoes, menu);
        menuItemOrdenar = menu.findItem(R.id.menuItemOrdenar);
        menuItemModoNoturno = menu.findItem(R.id.menuItemModoNoturno);
        atualizarTextoModoNoturno();
        return true;
    }

    // Prepara o menu de opções para a exibição
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        atualizarIconeOrdenacao();
        return true;
    }

    // Lida com a seleção dos itens do menu de opções
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.menuItemAdicionar) {
            abrirCadastroReceita();
            return true;
        } else if (item.getItemId() == R.id.menuItemSobre) {
            abrirSobre();
            return true;
        } else if (item.getItemId() == R.id.menuItemOrdenar) {
            salvarConfigOrdenacaoCrescente(!ordenacaoCrescente);
            atualizarIconeOrdenacao();
            ordenarLista();
            return true;
        } else if (item.getItemId() == R.id.menuItemRestaurar) {
            restaurarPadroes();
            atualizarIconeOrdenacao();
            ordenarLista();
            Toast.makeText(this, R.string.padroes_restaurados, Toast.LENGTH_SHORT).show();
            return true;
        } else if (item.getItemId() == R.id.menuItemModoNoturno) {
            alternarModoNoturno();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    // Abre a tela de "Cadastro" de receita
    private void abrirCadastroReceita() {
        Intent intent = new Intent(this, CadastroReceitasActivity.class);
        intent.putExtra(CadastroReceitasActivity.KEY_MODO, CadastroReceitasActivity.MODO_CADASTRAR);
        launcherCadastroReceita.launch(intent);
    }

    // Ordena a lista de receitas com base na configuração de ordenação
    private void ordenarLista() {

        if (ordenacaoCrescente) {
            listaReceitas.sort(Receita.ordenacaoCrescente);
        } else {
            listaReceitas.sort(Receita.ordenacaoDecrescente);
        }
        receitaAdapter.notifyDataSetChanged();
    }

    // Atualiza o ícone do item de ordenação no menu
    private void atualizarIconeOrdenacao() {

        if (ordenacaoCrescente) {
            menuItemOrdenar.setIcon(R.drawable.ic_sort_alpha_asc);
        } else {
            menuItemOrdenar.setIcon(R.drawable.ic_sort_alpha_desc);
        }
    }

    // Alterna para o modo noturno
    private void alternarModoNoturno() {
        modoNoturno = !modoNoturno;
        salvarConfigModoNoturno(modoNoturno);
        aplicarTema();
        atualizarTextoModoNoturno();
        recreate();
    }
    // Atualiza o texto do item de modo noturno no menu
    private void atualizarTextoModoNoturno() {

        if (modoNoturno) {
            menuItemModoNoturno.setTitle(R.string.modo_claro);
        } else {
            menuItemModoNoturno.setTitle(R.string.modo_noturno);
        }
    }

    // Abre a tela "Sobre"
    private void abrirSobre() {
        startActivity(new Intent(this, SobreActivity.class));
    }

    // Abre a tela de "Edição" da receita selecionada
    private void editarReceita() {
        if (isPosicaoValida()) {
            Receita receita = listaReceitas.get(posicaoSelecionada);
            Intent intent = new Intent(this, CadastroReceitasActivity.class);
            intent.putExtra(CadastroReceitasActivity.KEY_MODO, CadastroReceitasActivity.MODO_EDITAR);
            intent.putExtra(CadastroReceitasActivity.KEY_NOME, receita.getNome());
            intent.putExtra(CadastroReceitasActivity.KEY_INGREDIENTES, receita.getIngredientes());
            intent.putExtra(CadastroReceitasActivity.KEY_MODO_PREPARO, receita.getModoPreparo());
            intent.putExtra(CadastroReceitasActivity.KEY_TEMPO_PREPARO, receita.getTempoPreparo());
            intent.putExtra(CadastroReceitasActivity.KEY_CATEGORIA, receita.getCategoria());
            intent.putExtra(CadastroReceitasActivity.KEY_FAVORITA, receita.isFavorita());
            launcherEditarReceita.launch(intent);
        } else {
            exibirMensagemErro();
        }
    }

    // Exclui a receita selecionada
    private void excluirReceita() {

        if (isPosicaoValida()) {
            listaReceitas.remove(posicaoSelecionada);
            receitaAdapter.notifyDataSetChanged();
            Toast.makeText(this, R.string.receita_excluida, Toast.LENGTH_SHORT).show();
        } else {
            exibirMensagemErro();
        }
        posicaoSelecionada = -1;
    }

    // Verifica se a posição selecionada é válida
    private boolean isPosicaoValida() {
        return posicaoSelecionada >= 0 && posicaoSelecionada < listaReceitas.size();
    }

    // Exibe um alerta caso a posição selecionada seja inválida
    private void exibirMensagemErro() {
        Toast.makeText(this, R.string.erro_posicao_invalida, Toast.LENGTH_SHORT).show();
    }

    // Callback para gerenciar ações do ActionMode (menu contextual)
    private final ActionMode.Callback actionCallback = new ActionMode.Callback() {

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            mode.getMenuInflater().inflate(R.menu.lista_receitas_item_selecionado, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {

            if (item.getItemId() == R.id.menuItemEditar) {
                editarReceita();
                return true;
            } else if (item.getItemId() == R.id.menuItemExcluir) {
                excluirReceita();
                mode.finish();
                return true;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            if (itemSelecionado != null) {
                itemSelecionado.setBackground(backgroundItem);
            }

            listViewReceitas.setEnabled(true);
            actionMode = null;
            itemSelecionado = null;
            posicaoSelecionada = -1;
        }
    };

    // Launchers para capturar o retorno das activities de cadastro e edição
    private final ActivityResultLauncher<Intent> launcherCadastroReceita = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), this::tratarResultadoCadastro);

    private final ActivityResultLauncher<Intent> launcherEditarReceita = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), this::tratarResultadoEdicao);

    // Processa o resultado do cadastro de receita
    private void tratarResultadoCadastro(ActivityResult result) {

        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
            Bundle bundle = result.getData().getExtras();

            if (bundle != null) {
                Receita receita = new Receita(
                        bundle.getString(CadastroReceitasActivity.KEY_NOME),
                        bundle.getString(CadastroReceitasActivity.KEY_INGREDIENTES),
                        bundle.getString(CadastroReceitasActivity.KEY_MODO_PREPARO),
                        bundle.getString(CadastroReceitasActivity.KEY_TEMPO_PREPARO),
                        bundle.getInt(CadastroReceitasActivity.KEY_CATEGORIA),
                        bundle.getBoolean(CadastroReceitasActivity.KEY_FAVORITA)
                );
                listaReceitas.add(receita);
                ordenarLista();
            }
        }
    }

    // Processa o resultado da edição de receita
    private void tratarResultadoEdicao(ActivityResult result) {

        if (result.getResultCode() == RESULT_OK || result.getResultCode() == RESULT_CANCELED) {

            if (actionMode != null) {
                actionMode.finish();
            }
        }

        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
            Bundle bundle = result.getData().getExtras();

            if (bundle != null && isPosicaoValida()) {
                Receita receitaEditada = new Receita(
                        bundle.getString(CadastroReceitasActivity.KEY_NOME),
                        bundle.getString(CadastroReceitasActivity.KEY_INGREDIENTES),
                        bundle.getString(CadastroReceitasActivity.KEY_MODO_PREPARO),
                        bundle.getString(CadastroReceitasActivity.KEY_TEMPO_PREPARO),
                        bundle.getInt(CadastroReceitasActivity.KEY_CATEGORIA),
                        bundle.getBoolean(CadastroReceitasActivity.KEY_FAVORITA)
                );
                listaReceitas.set(posicaoSelecionada, receitaEditada);
                ordenarLista();
            } else {
                exibirMensagemErro();
            }
            posicaoSelecionada = -1;
        }
    }

    // Salva a configuração de ordenação crescente nas preferências
    private void salvarConfigOrdenacaoCrescente(boolean novoValor) {
        SharedPreferences shared = getSharedPreferences(ListaReceitasActivity.ARQUIVO_PREFERENCIAS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = shared.edit();
        editor.putBoolean(KEY_ORDENACAO_CRESCENTE, novoValor);
        editor.apply();
        ordenacaoCrescente = novoValor;
    }

    // Salva a configuração de modo noturno nas preferências
    private void salvarConfigModoNoturno(boolean novoValor) {
        SharedPreferences shared = getSharedPreferences(ARQUIVO_PREFERENCIAS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = shared.edit();
        editor.putBoolean(KEY_MODO_NOTURNO, novoValor);
        editor.apply();
    }

    // Restaura os padrões das preferências
    private void restaurarPadroes() {
        SharedPreferences shared = getSharedPreferences(ARQUIVO_PREFERENCIAS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = shared.edit();
        editor.clear();
        editor.apply();
        ordenacaoCrescente = PADRAO_INICIAL_ORDENACAO_CRESCENTE;
        modoNoturno = PADRAO_INICIAL_MODO_NOTURNO;
        recreate();
    }
}
