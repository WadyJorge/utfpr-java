package com.wadyjorge.receitix;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListaReceitasActivity extends AppCompatActivity {

    private ListView listViewReceitas;
    private ArrayList<Receita> listaReceitas;
    private ReceitaAdapter receitaAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_receitas);
        setTitle(R.string.lista_de_receitas);

        listViewReceitas = findViewById(R.id.listViewReceitas);

        listaReceitas = new ArrayList<>();
        receitaAdapter = new ReceitaAdapter(this, listaReceitas);
        listViewReceitas.setAdapter(receitaAdapter);

        listViewReceitas.setOnItemClickListener((parent, view, position, id) -> {
            Receita receita = (Receita) parent.getItemAtPosition(position);
            Toast.makeText(this,
                    getString(R.string.clicou_em) + receita.getNome(),
                    Toast.LENGTH_SHORT).show();
        });
    }

    public void abrirCadastroReceita(View view) {
        Intent intent = new Intent(this, CadastroReceitasActivity.class);
        launcherCadastroReceita.launch(intent);
    }

    public void abrirSobre(View view) {
        Intent intent = new Intent(this, SobreActivity.class);
        startActivity(intent);
    }

    ActivityResultLauncher<Intent> launcherCadastroReceita = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent intent = result.getData();

                        if (intent != null) {
                            Bundle bundle = intent.getExtras();

                            if (bundle != null) {
                                String nome = bundle.getString(CadastroReceitasActivity.KEY_NOME);
                                String ingredientes = bundle.getString(CadastroReceitasActivity.KEY_INGREDIENTES);
                                String modoPreparo = bundle.getString(CadastroReceitasActivity.KEY_MODO_PREPARO);
                                String tempoPreparo = bundle.getString(CadastroReceitasActivity.KEY_TEMPO_PREPARO);
                                int categoria = bundle.getInt(CadastroReceitasActivity.KEY_CATEGORIA);
                                boolean favorito = bundle.getBoolean(CadastroReceitasActivity.KEY_FAVORITO);

                                Receita receita = new Receita(nome, ingredientes, modoPreparo, tempoPreparo, categoria, favorito);
                                listaReceitas.add(receita);

                                receitaAdapter.notifyDataSetChanged();
                            }
                        }
                    }
                }
            });
}
