package com.wadyjorge.receitix;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SobreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sobre);
        setTitle(R.string.sobre);
    }

    public void abrirSiteUtfpr(View view) {
        abrirSite("https://www.utfpr.edu.br");
    }

    public void abrirSiteAutoria(View view) {
        abrirSite("https://github.com/WadyJorge");
    }

    public void abrirSiteCurso(View view) {
        abrirSite("https://pos-graduacao-ead.cp.utfpr.edu.br/java/");
    }

    private void abrirSite(String endereco) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(endereco));

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this,
                    R.string.nenhum_aplicativo_paginas_web,
                    Toast.LENGTH_LONG).show();
        }
    }

    public void enviarEmailAutor(View view) {
        enviarEmail(new String[]{"wbeliche@live.com"},
                getString(R.string.contato_aplicativo));
    }

    private void enviarEmail(String[] enderecos, String assunto) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL, enderecos);
        intent.putExtra(Intent.EXTRA_SUBJECT, assunto);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this,
                    R.string.nenhum_aplicativo_email,
                    Toast.LENGTH_LONG).show();
        }
    }
}
