package com.wadyjorge.receitix;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class ReceitaAdapter extends BaseAdapter {

    private Context context;
    private List<Receita> listaReceitas;
    private String[] tipos;

    private static class ReceitaHolder {
        TextView txtValorNomeReceita;
        TextView txtValorTempoPreparo;
        TextView txtValorCategoria;
        TextView txtFavorito;
    }

    public ReceitaAdapter(Context context, List<Receita> listaReceitas) {
        this.context = context;
        this.listaReceitas = listaReceitas;

        tipos = context.getResources().getStringArray(R.array.categorias);
    }

    @Override
    public int getCount() {
        return listaReceitas.size();
    }

    @Override
    public Object getItem(int position) {
        return listaReceitas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ReceitaHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.item_lista_receitas, parent, false);

            holder = new ReceitaHolder();
            holder.txtValorNomeReceita = convertView.findViewById(R.id.textViewValorNomeReceita);
            holder.txtValorTempoPreparo = convertView.findViewById(R.id.textViewValorTempoPreparo);
            holder.txtValorCategoria = convertView.findViewById(R.id.textViewValorCategoria);
            holder.txtFavorito = convertView.findViewById(R.id.textViewFavorito);

            convertView.setTag(holder);
        } else {
            holder = (ReceitaHolder) convertView.getTag();
        }

        Receita receita = listaReceitas.get(position);

        holder.txtValorNomeReceita.setText(receita.getNome());
        holder.txtValorTempoPreparo.setText(receita.getTempoPreparo());
        holder.txtValorCategoria.setText(tipos[receita.getCategoria()]);
        holder.txtFavorito.setText(receita.isFavorito()
                ? context.getString(R.string.favorita_sim)
                : context.getString(R.string.favorita_nao));

        return convertView;
    }
}
