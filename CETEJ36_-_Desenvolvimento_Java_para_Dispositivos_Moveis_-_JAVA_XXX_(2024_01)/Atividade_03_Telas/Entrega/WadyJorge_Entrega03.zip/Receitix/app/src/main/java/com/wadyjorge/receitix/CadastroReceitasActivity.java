package com.wadyjorge.receitix;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroReceitasActivity extends AppCompatActivity {

    public static final String KEY_NOME = "KEY_NOME";
    public static final String KEY_INGREDIENTES = "KEY_INGREDIENTES";
    public static final String KEY_MODO_PREPARO = "KEY_MODO_PREPARO";
    public static final String KEY_TEMPO_PREPARO = "KEY_TEMPO_PREPARO";
    public static final String KEY_CATEGORIA = "KEY_CATEGORIA";
    public static final String KEY_FAVORITO = "KEY_FAVORITO";

    private EditText editTextNomeReceita, editTextIngredientes, editTextModoPreparo;
    private RadioGroup radioGroupTempoPreparo;
    private Spinner spinnerCategoria;
    private CheckBox checkBoxFavorito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_receitas);
        setTitle(R.string.cadastro_de_receitas);

        editTextNomeReceita = findViewById(R.id.editTextNomeReceita);
        editTextIngredientes = findViewById(R.id.editTextIngredientes);
        editTextModoPreparo = findViewById(R.id.editTextModoPreparo);
        radioGroupTempoPreparo = findViewById(R.id.radioGroupTempoPreparo);
        spinnerCategoria = findViewById(R.id.spinnerCategoria);
        checkBoxFavorito = findViewById(R.id.checkBoxFavorito);
    }

    public void salvarReceita(View view) {
        String nome = editTextNomeReceita.getText().toString().trim();

        if (nome.isEmpty()) {
            Toast.makeText(this,
                    R.string.nome_obrigatorio,
                    Toast.LENGTH_LONG).show();

            editTextNomeReceita.requestFocus();
            return;
        }

        String ingredientes = editTextIngredientes.getText().toString().trim();

        if (ingredientes.isEmpty()) {
            Toast.makeText(this,
                    R.string.ingredientes_obrigatorios,
                    Toast.LENGTH_LONG).show();

            editTextIngredientes.requestFocus();
            return;
        }

        String modoPreparo = editTextModoPreparo.getText().toString().trim();

        if (modoPreparo.isEmpty()) {
            Toast.makeText(this,
                    R.string.modo_preparo_obrigatorio,
                    Toast.LENGTH_LONG).show();

            editTextModoPreparo.requestFocus();
            return;
        }

        int radioId = radioGroupTempoPreparo.getCheckedRadioButtonId();
        String tempoPreparo;

        if (radioId == R.id.radioButtonMenos30) {
            tempoPreparo = getString(R.string.menos_de_30_min);
        } else if (radioId == R.id.radioButton30a60) {
            tempoPreparo = getString(R.string.de_30_min_1h);
        } else if (radioId == R.id.radioButtonMais1h) {
            tempoPreparo = getString(R.string.mais_de_1h);
        } else {
            Toast.makeText(this,
                    R.string.tempo_preparo_obrigatorio,
                    Toast.LENGTH_SHORT).show();

            radioGroupTempoPreparo.requestFocus();
            return;
        }

        int categoria = spinnerCategoria.getSelectedItemPosition();

        if (categoria == AdapterView.INVALID_POSITION) {
            Toast.makeText(this,
                    R.string.categoria_obrigatoria,
                    Toast.LENGTH_LONG).show();

            spinnerCategoria.requestFocus();
            return;
        }

        boolean favorito = checkBoxFavorito.isChecked();

        Intent intentResposta = new Intent();

        intentResposta.putExtra(KEY_NOME, nome);
        intentResposta.putExtra(KEY_INGREDIENTES, ingredientes);
        intentResposta.putExtra(KEY_MODO_PREPARO, modoPreparo);
        intentResposta.putExtra(KEY_TEMPO_PREPARO, tempoPreparo);
        intentResposta.putExtra(KEY_CATEGORIA, categoria);
        intentResposta.putExtra(KEY_FAVORITO, favorito);

        setResult(CadastroReceitasActivity.RESULT_OK, intentResposta);
        finish();

        Toast.makeText(this,
                getString(R.string.receita_cadastrada),
                Toast.LENGTH_LONG).show();
    }

    public void limparCampos(View view) {
        editTextNomeReceita.setText("");
        editTextIngredientes.setText("");
        editTextModoPreparo.setText("");
        radioGroupTempoPreparo.clearCheck();
        spinnerCategoria.setSelection(0);
        checkBoxFavorito.setChecked(false);

        editTextNomeReceita.requestFocus();
        Toast.makeText(this,
                R.string.entradas_apagadas,
                Toast.LENGTH_LONG).show();
    }
}
