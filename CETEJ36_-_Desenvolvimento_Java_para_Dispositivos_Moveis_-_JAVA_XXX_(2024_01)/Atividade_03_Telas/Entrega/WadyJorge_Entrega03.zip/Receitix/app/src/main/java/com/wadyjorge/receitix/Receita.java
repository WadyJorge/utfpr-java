package com.wadyjorge.receitix;

public class Receita {
    private String nome;
    private String ingredientes;
    private String modoPreparo;
    private String tempoPreparo;
    private int categoria;
    private boolean favorito;

    public Receita(String nome, String ingredientes, String modoPreparo, String tempoPreparo, int categoria, boolean favorito) {
        this.nome = nome;
        this.ingredientes = ingredientes;
        this.modoPreparo = modoPreparo;
        this.tempoPreparo = tempoPreparo;
        this.categoria = categoria;
        this.favorito = favorito;
    }

    public String getNome() {
        return nome;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public String getModoPreparo() {
        return modoPreparo;
    }

    public String getTempoPreparo() {
        return tempoPreparo;
    }

    public int getCategoria() {
        return categoria;
    }

    public boolean isFavorito() {
        return favorito;
    }
}
