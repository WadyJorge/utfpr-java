package com.wadyjorge.receitix;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListaReceitasActivity extends AppCompatActivity {

    private ListView listViewReceitas;
    private ArrayList<Receita> listaReceitas;
    private ReceitaAdapter receitaAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_receitas);

        listViewReceitas = findViewById(R.id.listViewReceitas);

        popularListaReceitas();

        listViewReceitas.setOnItemClickListener((parent, view, position, id) -> {
            Receita receita = (Receita) parent.getItemAtPosition(position);

            Toast.makeText(
                    this,
                    getString(R.string.clicou_em) + receita.getNome(),
                    Toast.LENGTH_SHORT).show();
        });
    }

    private void popularListaReceitas() {
        listaReceitas = carregarReceitas();
        receitaAdapter = new ReceitaAdapter(this, listaReceitas);
        listViewReceitas.setAdapter(receitaAdapter);
    }

    private ArrayList<Receita> carregarReceitas() {
        ArrayList<Receita> listaReceitas = new ArrayList<>();

        String[] nomes = getResources().getStringArray(R.array.nomes_receitas);
        String[] tempos = getResources().getStringArray(R.array.tempos_preparo);
        String[] categorias = getResources().getStringArray(R.array.categorias);
        int[] favoritos = getResources().getIntArray(R.array.favoritos);

        for (int i = 0; i < nomes.length; i++) {
            boolean favorito = (favoritos[i] == 1);

            int categoriaId = i % categorias.length;

            Receita receita = new Receita(
                    nomes[i],
                    categoriaId,
                    tempos[i],
                    favorito);

            listaReceitas.add(receita);
        }

        return listaReceitas;
    }
}
