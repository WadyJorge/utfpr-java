package com.wadyjorge.receitix;

public class Receita {
    private String nome;
    private String tempoPreparo;
    private int categoria;
    private boolean favorito;

    public Receita(String nome, int categoria, String tempoPreparo, boolean favorito) {
        this.nome = nome;
        this.tempoPreparo = tempoPreparo;
        this.categoria = categoria;
        this.favorito = favorito;
    }

    public String getNome() {
        return nome;
    }

    public String getTempoPreparo() {
        return tempoPreparo;
    }

    public int getCategoria() {
        return categoria;
    }

    public boolean isFavorito() {
        return favorito;
    }
}
