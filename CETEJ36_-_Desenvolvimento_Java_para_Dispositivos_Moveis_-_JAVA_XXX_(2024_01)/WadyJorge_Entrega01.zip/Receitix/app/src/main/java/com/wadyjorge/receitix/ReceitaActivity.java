package com.wadyjorge.receitix;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ReceitaActivity extends AppCompatActivity {

    private EditText editNomeReceita, editIngredientes, editModoPreparo;
    private RadioGroup radioTempoPreparo;
    private Spinner spinnerCategoria;
    private CheckBox checkFavorito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receita);

        editNomeReceita = findViewById(R.id.editNomeReceita);
        editIngredientes = findViewById(R.id.editIngredientes);
        editModoPreparo = findViewById(R.id.editModoPreparo);
        radioTempoPreparo = findViewById(R.id.radioTempoPreparo);
        spinnerCategoria = findViewById(R.id.spinnerCategoria);
        checkFavorito = findViewById(R.id.checkFavorito);
    }

    public void salvarReceita(View view) {
        String nome = editNomeReceita.getText().toString().trim();

        if (nome.isEmpty()) {
            Toast.makeText(this,
                    R.string.nome_obrigatorio,
                    Toast.LENGTH_LONG).show();

            editNomeReceita.requestFocus();
            return;
        }

        String ingredientes = editIngredientes.getText().toString().trim();

        if (ingredientes.isEmpty()) {
            Toast.makeText(this,
                    R.string.ingredientes_obrigatorios,
                    Toast.LENGTH_LONG).show();

            editIngredientes.requestFocus();
            return;
        }

        String modoPreparo = editModoPreparo.getText().toString().trim();

        if (modoPreparo.isEmpty()) {
            Toast.makeText(this,
                    R.string.modo_preparo_obrigatorio,
                    Toast.LENGTH_LONG).show();

            editModoPreparo.requestFocus();
            return;
        }

        String categoria = spinnerCategoria.getSelectedItem().toString();

        if (categoria.isEmpty()) {
            Toast.makeText(this,
                    R.string.categoria_obrigatoria,
                    Toast.LENGTH_LONG).show();

            spinnerCategoria.requestFocus();
            return;
        }

        boolean favorito = checkFavorito.isChecked();

        int radioId = radioTempoPreparo.getCheckedRadioButtonId();
        String tempoPreparo;

        if (radioId == R.id.radioMenos30) {
            tempoPreparo = getString(R.string.menos_de_30_min);
        } else if (radioId == R.id.radio30a60) {
            tempoPreparo = getString(R.string.de_30_min_1h);
        } else if (radioId == R.id.radioMais1h) {
            tempoPreparo = getString(R.string.mais_de_1h);
        } else {
            Toast.makeText(this,
                    R.string.tempo_preparo_obrigatorio,
                    Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this,
                getString(R.string.receita_cadastrada) + "\n" +
                        getString(R.string.nome_valor) + " " + nome + "\n" +
                        getString(R.string.categoria_valor) + " " + categoria + "\n" +
                        getString(R.string.tempo_preparo_valor) + " " + tempoPreparo + "\n" +
                        getString(favorito ? R.string.favorita_sim : R.string.favorita_nao),
                Toast.LENGTH_LONG).show();
    }

    public void limparCampos(View view) {
        editNomeReceita.setText("");
        editIngredientes.setText("");
        editModoPreparo.setText("");
        radioTempoPreparo.clearCheck();
        spinnerCategoria.setSelection(0);
        checkFavorito.setChecked(false);

        editNomeReceita.requestFocus();
        Toast.makeText(this,
                R.string.entradas_apagadas,
                Toast.LENGTH_LONG).show();
    }
}
