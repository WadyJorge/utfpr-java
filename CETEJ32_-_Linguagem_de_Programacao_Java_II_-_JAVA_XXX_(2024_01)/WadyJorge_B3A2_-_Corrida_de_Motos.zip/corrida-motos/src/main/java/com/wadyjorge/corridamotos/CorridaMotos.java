package com.wadyjorge.corridamotos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CorridaMotos {

    private static final int TOTAL_COMPETIDORES = 10;
    private static final int TOTAL_CORRIDAS = 10;

    private final List<Competidor> competidores = new ArrayList<>();
    private final Lock lock = new ReentrantLock();
    private int[] pontuacao;

    public CorridaMotos() {
        // Cria os competidores
        for (int i = 0; i < TOTAL_COMPETIDORES; i++) {
            competidores.add(new Competidor("Competidor #" + (i + 1)));
        }

        // Realiza as corridas
        for (int i = 0; i < TOTAL_CORRIDAS; i++) {
            realizarCorrida();
        }

        // Exibe o resultado final do campeonato
        exibirResultadoFinal();
    }

    private void realizarCorrida() {
        pontuacao = new int[TOTAL_COMPETIDORES];
        List<Thread> threads = new ArrayList<>();

        for (Competidor competidor : competidores) {
            threads.add(new Thread(competidor));
        }

        for (Thread thread : threads) {
            thread.start();
        }

        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Atualiza a pontuação dos competidores
        atualizarPontuacao();

        System.out.println("Corrida concluída. Pontuação atual:");
        for (Competidor competidor : competidores) {
            System.out.println(competidor.nome + " com " + competidor.pontos + " pontos");
        }
    }

    private void atualizarPontuacao() {
        synchronized (competidores) {
            Collections.sort(competidores);
            for (int i = 0; i < competidores.size(); i++) {
                competidores.get(i).pontos += TOTAL_COMPETIDORES - i;
            }
        }
    }

    private void exibirResultadoFinal() {
        System.out.println("\n========== Pódio =========");
        competidores.sort((c1, c2) -> Integer.compare(c2.pontos, c1.pontos));

        for (int i = 0; i < 3; i++) {
            Competidor competidor = competidores.get(i);
            System.out.println(competidor.nome + " com " + competidor.pontos + " pontos");
        }

        System.out.println("\n==== Tabela de Pontos ====");
        for (Competidor competidor : competidores) {
            System.out.println(competidor.nome + " com " + competidor.pontos + " pontos");
        }
    }

    public static void main(String[] args) {
        new CorridaMotos();
    }

    private class Competidor implements Runnable, Comparable<Competidor> {
        private final String nome;
        private int pontos;
        private int chegada;

        public Competidor(String nome) {
            this.nome = nome;
            this.pontos = 0;
        }

        @Override
        public void run() {
            try {
                Thread.sleep((int) (Math.random() * 1000)); // Simula o tempo de corrida
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Acessa a região crítica (linha de chegada)
            lock.lock();
            try {
                chegada = ++pontuacao[0]; // Incrementa a chegada e salva a posição
            } finally {
                lock.unlock();
            }
        }

        @Override
        public int compareTo(Competidor o) {
            return Integer.compare(this.chegada, o.chegada);
        }
    }
}