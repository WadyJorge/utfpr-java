package br.edu.utfpr.cp.espjava.crudcidades;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudCidadesApplicationTests {

	@Test
	void contextLoads() {
	}

}
