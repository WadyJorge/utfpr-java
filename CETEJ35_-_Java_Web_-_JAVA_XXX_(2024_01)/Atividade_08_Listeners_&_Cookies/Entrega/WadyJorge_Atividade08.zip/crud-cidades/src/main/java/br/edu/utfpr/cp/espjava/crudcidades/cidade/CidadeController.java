package br.edu.utfpr.cp.espjava.crudcidades.cidade;

import br.edu.utfpr.cp.espjava.crudcidades.entity.CidadeEntity;
import br.edu.utfpr.cp.espjava.crudcidades.repository.CidadeRepository;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Controller
public class CidadeController {

    private final CidadeRepository cidadeRepository;
    private Set<Cidade> cidades;

    public CidadeController(final CidadeRepository cidadeRepository) {
        this.cidadeRepository = cidadeRepository;
    }

    @GetMapping("/")
    public String listar(Model memoria,
                         Principal usuario,
                         HttpSession sessao,
                         HttpServletResponse response) {

        memoria.addAttribute("listaCidades",
                this.converterCidade(cidadeRepository.findAll()));

        if (usuario != null) {
            memoria.addAttribute("usuarioAtual", usuario.getName());
        }

        sessao.setAttribute("usuarioAtual", usuario.getName());
        response.addCookie(new Cookie("listar", LocalDateTime.now().toString()));

        return "/crud";
    }

    private List<Cidade> converterCidade(List<CidadeEntity> cidades){
        return cidades.stream().map(cidade ->
                new Cidade(cidade.getNome(), cidade.getEstado())).collect(Collectors.toList());
    }

    @PostMapping("/criar")
    public String criar(@Valid Cidade cidade,
                        BindingResult validacao,
                        Model memoria,
                        HttpServletResponse response) {

        if (validacao.hasErrors()) {
            validacao.getFieldErrors().forEach(error ->
                    memoria.addAttribute(error.getField(), error.getDefaultMessage())
            );

            memoria.addAttribute("nomeInformado", cidade.getNome());
            memoria.addAttribute("estadoInformado", cidade.getEstado());
            memoria.addAttribute("listaCidades",
                    this.converterCidade(cidadeRepository.findAll()));

            response.addCookie(new Cookie("criar", LocalDateTime.now().toString()));

            return "/crud";
        } else {
            cidadeRepository.save(cidade.clonar());
        }

        return "redirect:/";
    }

    @GetMapping("/preparaAlterar")
    public String preparaAlterar(@RequestParam String nome,
                                 @RequestParam String estado,
                                 Model memoria) {

        var cidadeAtual = cidadeRepository.findByNomeAndEstado(nome, estado);

        cidadeAtual.ifPresent(cidadeEncontrada -> {
            memoria.addAttribute("cidadeAtual", cidadeEncontrada);
            memoria.addAttribute("listaCidades",
                    this.converterCidade(cidadeRepository.findAll()));
        });

        return "/crud";
    }

    @PostMapping("/alterar")
    public String alterar(@RequestParam String nomeAtual,
                          @RequestParam String estadoAtual,
                          @Valid Cidade cidade,
                          BindingResult validacao,
                          Model memoria,
                          HttpServletResponse response) {

        var cidadeAtual = cidadeRepository.findByNomeAndEstado(nomeAtual, estadoAtual);

        if(cidadeAtual.isPresent()){
            var cidadeEncontrada = cidadeAtual.get();
            cidadeEncontrada.setNome(cidade.getNome());
            cidadeEncontrada.setEstado(cidade.getEstado());

            cidadeRepository.saveAndFlush(cidadeEncontrada);
        }

        response.addCookie(new Cookie("alterar", LocalDateTime.now().toString()));

        return "redirect:/";

    }

    @GetMapping("/excluir")
    public String excluir(@RequestParam String nome,
                          @RequestParam String estado,
                          HttpServletResponse response) {

        var cidadeEstadoEncontrada = cidadeRepository.findByNomeAndEstado(nome, estado);

        cidadeEstadoEncontrada.ifPresent(cidadeRepository::delete);

        response.addCookie(new Cookie("excluir", LocalDateTime.now().toString()));

        return "redirect:/";
    }

    @GetMapping("/mostrar")
    @ResponseBody
    public String mostraCookie(@CookieValue String listar) {
        return "Último acesso ao método listar(): " + listar;
    }
}
