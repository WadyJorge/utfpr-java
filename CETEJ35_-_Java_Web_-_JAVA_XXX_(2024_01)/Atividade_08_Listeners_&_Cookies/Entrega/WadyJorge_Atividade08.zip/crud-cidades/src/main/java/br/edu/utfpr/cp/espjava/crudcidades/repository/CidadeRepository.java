package br.edu.utfpr.cp.espjava.crudcidades.repository;

import br.edu.utfpr.cp.espjava.crudcidades.entity.CidadeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CidadeRepository extends JpaRepository<CidadeEntity, Long> {
    public Optional<CidadeEntity> findByNomeAndEstado(String nome, String estado);
}
