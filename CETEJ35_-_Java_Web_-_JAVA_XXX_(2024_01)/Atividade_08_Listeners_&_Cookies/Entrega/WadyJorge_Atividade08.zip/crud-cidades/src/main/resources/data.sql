INSERT INTO usuario VALUES (1, 'Wady', '$2a$10$ZimAXunGEpSopR22Cj/M9.ctvn6DhTUCUgxLgzGZNOy7TC6GZqqs2');
INSERT INTO usuario VALUES (2, 'John', '$2a$10$ZimAXunGEpSopR22Cj/M9.ctvn6DhTUCUgxLgzGZNOy7TC6GZqqs2');
INSERT INTO usuario VALUES (3, 'Anna', '$2a$10$ZimAXunGEpSopR22Cj/M9.ctvn6DhTUCUgxLgzGZNOy7TC6GZqqs2');

INSERT INTO usuario_papeis VALUES (1, 'admin');
INSERT INTO usuario_papeis VALUES (2, 'listar');
INSERT INTO usuario_papeis VALUES (3, 'listar');
