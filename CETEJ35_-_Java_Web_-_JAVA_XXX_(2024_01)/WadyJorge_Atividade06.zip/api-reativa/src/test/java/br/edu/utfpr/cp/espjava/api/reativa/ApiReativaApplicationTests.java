package br.edu.utfpr.cp.espjava.api.reativa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiReativaApplicationTests {

	@Test
	void contextLoads() {
	}

}
