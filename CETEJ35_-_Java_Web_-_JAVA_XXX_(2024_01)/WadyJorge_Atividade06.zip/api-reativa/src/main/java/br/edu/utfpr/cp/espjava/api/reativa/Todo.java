package br.edu.utfpr.cp.espjava.api.reativa;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public record Todo(String id, String titulo, String descricao, boolean feito) {

    public Todo {
        if (titulo == null || titulo.length() < 3) {
            throw new IllegalArgumentException("O título precisa ter mais de 3 caracteres.");
        }
    }
}
