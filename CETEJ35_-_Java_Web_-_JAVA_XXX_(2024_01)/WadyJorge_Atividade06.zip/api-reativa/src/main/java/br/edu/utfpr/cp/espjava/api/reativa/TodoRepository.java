package br.edu.utfpr.cp.espjava.api.reativa;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface TodoRepository extends ReactiveMongoRepository<Todo, String> {

    Flux<Todo> findByFeito(boolean feito);
}
