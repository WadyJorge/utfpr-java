# XmlOPS
Manipulação de XML em Java. Um exemplo com a estrutura dentro do pacote model. Cria XSD a partir de qualquer .jar

Ambiente de desenvolvimento:

- NetBeans 12.4

- jdk11

- Maven

*inclui o uso do Jakata XML bind
