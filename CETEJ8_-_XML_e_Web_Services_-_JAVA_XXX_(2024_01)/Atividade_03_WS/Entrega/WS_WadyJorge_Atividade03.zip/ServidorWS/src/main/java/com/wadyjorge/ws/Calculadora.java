package com.wadyjorge.ws;

import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;

// @author Wady Jorge
@WebService(serviceName = "Calculadora")
public class Calculadora {

    @WebMethod(operationName = "somar")
    public int somar(@WebParam(name = "v1") int v1, @WebParam(name = "v2") int v2) {
        return v1 + v2;
    }
}
