package com.wadyjorge.clientews;

import com.wadyjorge.clientews.Calculadora;
import com.wadyjorge.clientews.Calculadora_Service;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculadoraGUI {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Calculadora WS");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponents(panel);

        frame.setVisible(true);
    }

    private static void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel v1Label = new JLabel("Primeiro valor:");
        v1Label.setBounds(10, 20, 120, 25);
        panel.add(v1Label);

        JTextField v1Text = new JTextField(20);
        v1Text.setBounds(130, 20, 150, 25);
        panel.add(v1Text);

        JLabel v2Label = new JLabel("Segundo valor:");
        v2Label.setBounds(10, 50, 120, 25);
        panel.add(v2Label);

        JTextField v2Text = new JTextField(20);
        v2Text.setBounds(130, 50, 150, 25);
        panel.add(v2Text);

        JButton somarButton = new JButton("Somar");
        somarButton.setBounds(10, 80, 270, 25);
        panel.add(somarButton);

        JLabel resultadoLabel = new JLabel("Resultado:");
        resultadoLabel.setBounds(10, 110, 120, 25);
        panel.add(resultadoLabel);

        JTextField resultadoText = new JTextField(20);
        resultadoText.setBounds(130, 110, 150, 25);
        resultadoText.setEditable(false);
        resultadoText.setBackground(Color.WHITE);
        panel.add(resultadoText);

        // Ação do botão "Somar"
        somarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int v1 = Integer.parseInt(v1Text.getText());
                    int v2 = Integer.parseInt(v2Text.getText());

                    Calculadora_Service service = new Calculadora_Service();
                    Calculadora calculadora = service.getCalculadoraPort();

                    int resultado = calculadora.somar(v1, v2);

                    resultadoText.setText(String.valueOf(resultado));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panel, "Por favor, insira números válidos!", "Erro", JOptionPane.ERROR_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(panel, "Erro ao chamar o Web Service: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}
